# Arranger — native Android .STY arranger player

Kotlin + Jetpack Compose UI, **native audio** (software synthesizer → PCM → `AudioTrack`).
No WebView, so browser autoplay rules do not apply.

```
.STY ─► StyParser (SMF + markers) ─► CasmParser (CASM/Ctab/Ctb2/Cntt)
     ─► StyleEngine: sections, queue/auto-fill, tempo clock, chord → NTR/NTT transposition,
                     RTR retrigger/glide, multi pads, metronome  ─► sample-accurate events
     ─► Synth: PolyBLEP oscillators + filter + ADSR, synthesized GM drum kit, mixer buses,
               reverb, soft limiter ─► 16-bit PCM ─► AudioTrack (low-latency) ─► speaker/headphones
USB/Bluetooth MIDI keyboard ─► MidiInputController ─► chord recognizer ─► engine (via lock-free command queue)
```

## Easiest: build the APK in the cloud
See `INSTALL_ON_PHONE.md` - upload this folder to a free GitHub repository; the included workflow publishes `Arranger.apk` as a release you open on your phone.

## Build and install (Android Studio)
1. Install **Android Studio** (Koala or newer) with SDK 34.
2. *File ▸ Open* → this `AndroidNativeApp` folder; let Gradle sync (needs internet once).
   (The Gradle wrapper *jar* is not included; Android Studio supplies Gradle, or run `gradle wrapper` once.)
3. Plug in a phone (USB debugging on) or start an emulator, press **Run ▸ app**.
   Command line: `gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` → `adb install -r` it.

No permissions are requested: files are chosen with the system picker, audio *output* needs none,
and there is no INTERNET permission (fully offline).

## First-run test on the phone (your 12 steps)
The app opens with the bundled `DemoPop110.sty` and four demo pads already loaded.
1. Tap **OPEN .STY** and pick a `.sty` (or keep the demo).  2. The header shows style name/section count.
3. Tap **MAIN A**.  4. Tap **▶ START** — you should hear drums, bass, chords at 110 BPM; the AUDIO chip must read
"AUDIO 48.0 kHz" and the part chips/meters light up.  5. Tap a chord root/type (or play a USB/BT MIDI keyboard):
bass and chords re-voice instantly.  6. Tap **FILL A**, **BREAK**, **MAIN B** (auto-fill, on the next bar line),
**ENDING 1** (plays, then stops).  7. Change **BPM** with ± / TAP; bar length must follow it; **TEMPO LOCK** keeps
BPM when you load another style (load a second style while playing: it swaps at the next bar line).
Multi pads: tap a pad; **LOAD .MID** assigns your own MIDI file; **CHORD** makes it follow the played chord.

## Verification status - read this
| Check | Result |
|---|---|
| Format offsets, bit tables, transposition rules re-checked against the public format document; 8 defects found and fixed (see docs) | done |
| Executable Python mirror of the Kotlin logic: 12-step pipeline scenario (`tools/test_pipeline.py`) | **33/33 pass** |
| Audit suite for every fixed defect + edge-case styles: Ctb2/SFF2 1920 PPQN, Cntt, chord/note mute, unknown markers, bank select, CC11, intro landing, truncation robustness (`tools/test_audit.py`) | **37/37 pass** |
| Synth recipes ported to numpy and rendered (`tools/render_preview.py`): non-silent, no clipping, correct section order | pass |
| Bracket balance of all Kotlin files | pass |
| **Kotlin compiled** | **NO - no JDK/Kotlin/Android SDK was available** (the cloud build in INSTALL_ON_PHONE.md is the first real compile) |
| **Run on an Android device / sound heard from a phone** | **NO** |
| Tested with a real commercial .STY | **NO** (none available) |

## Limitations
* The synth is oscillator/filter based, **not a soundfont/sample player**: notes, timing and chords follow the
  style exactly, but timbres are generic per GM family (drums are synthesized).
* Audio runs while the app is in the foreground (no foreground service / lock-screen playback yet).
* See `docs/STY_NATIVE_FORMAT.md` for the parser's documented simplifications.

## Layout
`app/src/main/java/.../core` parser & engine · `.../audio` synth, AudioTrack output, MIDI input ·
`.../ui` Compose screen/theme/ViewModel · `app/src/main/assets/demo` bundled style + pads · `tools/` generators & tests.
