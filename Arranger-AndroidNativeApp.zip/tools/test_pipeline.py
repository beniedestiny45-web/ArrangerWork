#!/usr/bin/env python3
"""Runs the 12-step pipeline scenario against the generated .sty using the
Python mirror of the Kotlin core. Prints PASS/FAIL per check."""
import os, sys, collections
sys.path.insert(0, os.path.dirname(__file__))
from sty_mirror import *

STY = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'demo', 'DemoPop110.sty')
BLOCK = 256 / 48000.0
fails = 0
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))
    if not cond: fails += 1

def run(engine, seconds, out):
    n = int(seconds / BLOCK)
    for _ in range(n): engine.advance(BLOCK, out)

# 1-2 import + parse -----------------------------------------------------------
data = open(STY, 'rb').read()
doc = parse_sty(data)
check("1. import: file read", len(data) > 1000, f"{len(data)} bytes")
check("2. parse: style name", doc.name == "Demo Pop 110", doc.name)
check("2. parse: PPQN 480, tempo 110, 4/4", doc.ppqn == 480 and round(doc.tempo) == 110 and (doc.num, doc.den) == (4, 4))
want = {"Intro1", "Intro2", "MainA", "MainB", "MainC", "MainD", "FillA", "FillB", "FillC", "FillD", "Break", "Ending1", "Ending2"}
check("2. parse: all sections found (Intro/Main A-D/Fill A-D/Break/Ending)", want <= set(doc.sections), sorted(set(doc.sections)))
ma = doc.sections["MainA"]
check("2. parse: MainA = 2 bars (3840 ticks), 5 channels (by design of the demo)", ma.length == 3840 and len(ma.channels) == 5, f"{ma.length} ticks, {len(ma.channels)} ch")
mc = doc.sections["MainC"]
maps = {m.part: m for m, _ in ma.channels}
check("2. CASM: bass=RootTrans/Bass, chord1=RootFixed/Chord, rhythm=Bypass",
      (maps["Bass"].ntr, maps["Bass"].ntt) == ("RootTrans", "Bass") and (maps["Chord1"].ntr, maps["Chord1"].ntt) == ("RootFixed", "Chord") and maps["Rhythm"].ntt == "Bypass")
check("2. CASM: MainC routes 8 channels to 8 distinct parts", len({m.part for m, _ in mc.channels}) == 8)
check("2. setup measure: programs/volumes captured", doc.prog.get(10) == 33 and doc.vol.get(9) == 110, f"bass prog={doc.prog.get(10)}")

# 3-5 select variation, press Play, events produced ------------------------------
e = Engine(); e.load_style(doc); ev = []
e.request("MainA")
check("3. variation selected while stopped", e.current == "MainA")
e.start(); run(e, 2 * 60 / 110 * 4, ev)   # exactly 2 bars... 1 bar = 4*60/110 s
ons = [x for x in ev if x.type == "on"]
parts = collections.Counter(x.part for x in ons)
check("4/5. Play (MainA): note events on Rhythm/SubRhythm/Bass/Chord1/Pad", set(parts) == {"SubRhythm", "Rhythm", "Bass", "Chord1", "Pad"} and len(ons) > 40, dict(parts))
ec = Engine(); ec.load_style(doc); oc = []; ec.request("MainC"); ec.start(); run(ec, 4.4, oc)
pc = collections.Counter(x.part for x in oc if x.type == "on")
check("4/5. Play (MainC): events on ALL 8 accompaniment parts", len(pc) == 8, dict(pc))
check("5. events carry audible velocities (all > 0)", all(x.vel > 0 for x in ons))
first_kick = next(x for x in ons if x.part == "Rhythm" and x.note == 36)
check("5. downbeat kick fires at t=0 (tick-0 event not dropped)", first_kick.t < 0.01, f"t={first_kick.t:.4f}")

# 6-7 chord changes while playing -----------------------------------------------------
before = len(ev)
e.set_chord(0, "Maj", ev)                    # C major
run(e, 1.0, ev)
ev_c = [x for x in ev[before:] if x.type == "on" and x.part == "Chord1"]
pcs_c = {x.note % 12 for x in ev_c}
check("6. C major: Chord1 follows chord (C/E/G only)", pcs_c <= {0, 4, 7} and ev_c, sorted(pcs_c))
mark = len(ev)
e.set_chord(7, "Maj", ev)                    # G major mid-playback
run(e, 2.2, ev)
new = ev[mark:]
bass_on = [x for x in new if x.type == "on" and x.part == "Bass"]
ch_on = [x for x in new if x.type == "on" and x.part == "Chord1"]
check("7. G major: bass re-rooted (all bass pitch classes in G,B,D,C,F-ish rootTrans from C: shift -5)",
      bass_on and {x.note % 12 for x in bass_on} <= {(p - 5) % 12 for p in (0, 7, 5, 4)}, sorted({x.note % 12 for x in bass_on}))
check("7. G major: Chord1 re-voiced to G/B/D", ch_on and {x.note % 12 for x in ch_on} <= {7, 11, 2}, sorted({x.note % 12 for x in ch_on}))
drum_pitches = {x.note for x in new if x.type == "on" and x.part == "Rhythm"}
check("7. drums NOT re-pitched by chord change", drum_pitches <= {36, 38, 49, 50, 45}, sorted(drum_pitches))

# 8 fill, 9 break ---------------------------------------------------------------------------
e.log.clear(); e.request("FillA"); run(e, 4.6, ev)
seq = [s for _, s in e.log]
check("8. Fill: plays FillA then returns to MainA", seq[:2] == ["FillA", "MainA"], seq)
e.log.clear(); e.request("Break"); run(e, 4.6, ev)
seq = [s for _, s in e.log]
check("9. Break: plays Break then returns to last Main", seq[:2] == ["Break", "MainA"], seq)

# 10 change variation (auto-fill into the new main) ---------------------------------------------
e.log.clear(); e.request("MainB"); run(e, 6.5, ev)
seq = [s for _, s in e.log]
check("10. Variation change: auto Fill B then Main B", seq[:2] == ["FillB", "MainB"], seq)
check("10. transition happens on a bar line (no mid-bar cut)",
      all(abs(((t - e.log[0][0]) / (4 * 60 / 110)) % 1.0) < 0.02 or abs(((t - e.log[0][0]) / (4 * 60 / 110)) % 1.0 - 1) < 0.02 for t, _ in e.log))

# 11 ending -----------------------------------------------------------------------------------------
e.log.clear(); e.request("Ending1"); run(e, 9.0, ev)
check("11. Ending: switches to Ending A and transport stops after it", [s for _, s in e.log][:1] == ["Ending1"] and e.state == "Stopped", f"{e.log} state={e.state}")
bal = collections.Counter()
for x in ev:
    if x.type == "on": bal[x.key] += 1
    elif x.type == "off": bal[x.key] -= 1
check("11. no stuck notes: every note-on has a matching note-off", all(v == 0 for v in bal.values()), {k: v for k, v in bal.items() if v})

# 12 BPM sync ---------------------------------------------------------------------------------------------
def kick_times(tempo, bars=6):
    en = Engine(); en.load_style(doc); en.tempo = tempo; en.locked = True; out = []
    en.request("MainA"); en.start(); run(en, bars * 240 / tempo + 0.1, out)
    return [x.t for x in out if x.type == "on" and x.part == "Rhythm" and x.note == 36 and x.t >= 0]
for bpm in (110, 90, 140):
    kt = kick_times(bpm)
    bar_starts = [t for i, t in enumerate(kt) if i % 3 == 0]          # 3 kicks/bar in MainA (beats 1, 2.5, 4)
    gaps = [b - a for a, b in zip(bar_starts, bar_starts[1:])]
    check(f"12. {bpm} BPM: bar length = {240/bpm:.4f}s", gaps and all(abs(g - 240 / bpm) < 0.002 for g in gaps), f"gaps={[round(g, 4) for g in gaps[:3]]}")
# live tempo change
en = Engine(); en.load_style(doc); out = []; en.request("MainA"); en.start(); en.tempo = 110
run(en, 4.4, out); en.tempo = 150; mk = len(out); run(en, 6.0, out)
k = [x.t for x in out[mk:] if x.type == "on" and x.part == "Rhythm" and x.note == 36 and (x.t - out[mk].t) >= 0]
g = [b - a for a, b in zip(k[2::3], k[5::3])]
check("12. live tempo change 110->150 BPM re-times the next bars", g and all(abs(x - 240 / 150) < 0.003 for x in g), f"{[round(x,4) for x in g[:3]]}")

# extras: sync start, live style swap, tempo lock, retune/retrigger -----------------------------------------------------
e2 = Engine(); e2.load_style(doc); o2 = []; e2.request("MainA"); e2.sync_start(); run(e2, 1.0, o2)
check("X. Sync Start: silent until a chord is played", not o2 and e2.state == "SyncArmed")
e2.set_chord(5, "Maj", o2); run(e2, 0.5, o2)
check("X. Sync Start: starts on first chord and follows it (F)", e2.state == "Playing" and o2 and {x.note % 12 for x in o2 if x.type == "on" and x.part == "Chord1"} <= {5, 9, 0})
d2 = parse_sty(data); d2.name = "Second Style"; d2.tempo = 100.0
e2.load_style(d2, live=True); o3 = []; run(e2, 3.0, o3)
check("X. Live style switch: keeps playing, swaps at a bar line", e2.state == "Playing" and e2.doc.name == "Second Style" and o3)
e2.locked = True; e2.tempo = 123.0; d3 = parse_sty(data); d3.tempo = 80.0; e2.load_style(d3, live=True); run(e2, 3.0, o3)
check("X. Tempo Lock: new style keeps current tempo", abs(e2.tempo - 123.0) < 1e-6, e2.tempo)
e3 = Engine(); e3.load_style(doc); o4 = []; e3.request("MainA"); e3.start(); e3.set_chord(0, "Maj", o4); run(e3, 0.3, o4)
n_before = len([x for x in o4 if x.type == "on" and x.part == "Chord1"])
mk = len(o4); e3.set_chord(9, "min", o4)
chg = o4[mk:]
check("X. Chord change mid-note: sounding Chord1 notes retrigger (RTR=Retrigger) to the new chord",
      any(x.type == "off" and x.part == "Chord1" for x in chg) and any(x.type == "on" and x.part == "Chord1" for x in chg))
check("X. Chord change mid-note: sounding Pad/Chord2 notes glide (RTR=PitchShift) w/o re-attack",
      any(x.type == "retune" for x in chg))

print("\n%s" % ("ALL CHECKS PASSED" if fails == 0 else f"{fails} CHECK(S) FAILED"))
sys.exit(1 if fails else 0)
