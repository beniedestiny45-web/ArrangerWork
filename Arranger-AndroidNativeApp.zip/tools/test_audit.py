#!/usr/bin/env python3
"""Audit tests: one or more checks for every defect found when re-reading the format document."""
import os, sys, collections, struct
sys.path.insert(0, os.path.dirname(__file__))
from sty_mirror import *
import make_test_styles as T

fails = 0
def check(name, cond, extra=""):
    global fails
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else "")); fails += 0 if cond else 1
BLOCK = 256 / 48000.0
def run(e, sec, out):
    for _ in range(int(sec / BLOCK)): e.advance(BLOCK, out)
def mp(**k):
    d = dict(ch=11, part="Bass", ntr="RootTrans", ntt="Bass", root=0, tones={0, 4, 7, 11}, hi=5, lo=0, hil=127, rtr=1); d.update(k); return Mapping(**d)
DATA = os.path.join(os.path.dirname(__file__), 'testdata')
load = lambda n: parse_sty(open(os.path.join(DATA, n), 'rb').read())

# 1. Root Trans: upward 0..11, folded down above High Key (document example, High Key = F)
m = mp(); got = {r: transpose_note(48, m, r, {0, 4, 7}, False, False) - 48 for r in (0, 1, 2, 5, 6, 7, 11)}
check("1. RootTrans/HighKey F: C C# D F go UP (0,1,2,5)", [got[0], got[1], got[2], got[5]] == [0, 1, 2, 5], got)
check("1. RootTrans/HighKey F: F# goes DOWN 6, G down 5, B down 1", (got[6], got[7], got[11]) == (-6, -5, -1), got)
check("1. High Key is a real value: High Key C folds every root but C", transpose_note(48, mp(hi=0), 2, {0, 4, 7}, False, False) == 48 + 2 - 12)

# 2. Root Fixed: document example C3 E3 G3 -> C3 F3 A3 going C -> F (source triad)
mf = mp(ntr="RootFixed", ntt="Chord", tones={0, 4, 7}, hi=0)
r = [transpose_note(n, mf, 5, {0, 4, 7}, False, False) for n in (48, 52, 55)]
check("2. RootFixed C-E-G -> F major gives C-F-A (document example)", r == [48, 53, 57], r)
r = [transpose_note(n, mf, 2, {0, 3, 7, 10}, True, False) for n in (48, 52, 55)]
check("2. RootFixed to Dm7: distinct tones, no doubled pitch classes", len({x % 12 for x in r}) == 3, r)
m7 = mp(ntr="RootFixed", ntt="Chord", tones={0, 4, 7, 11}, hi=0)
r = [transpose_note(n, m7, 7, {0, 4, 7}, False, False) for n in (52, 55, 59)]
check("2. RootFixed 4-note source (E G B) -> G major: distinct, in register", len({x % 12 for x in r}) == 3 and all(45 <= x <= 70 for x in r), r)

# 3. Chord Mute / Note Mute / autostart
d = load("chordmute.sty"); sec = d.sections["MainA"]
pl = {m_.ch: m_.plays for m_, _ in sec.channels}
check("3. parse: ch11 plays Maj, not min; ch12 plays min, not Maj", "Maj" in pl[11] and "min" not in pl[11] and "min" in pl[12] and "Maj" not in pl[12], (sorted(pl[11])[:3], sorted(pl[12])[:3]))
auto = {m_.ch: m_.auto for m_, _ in sec.channels}
check("3. parse: autostart bit read (bass off, others on)", auto[10] is False and auto[9] is True and auto[11] is True, auto)
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); e.set_chord(0, "Maj", o); run(e, 2.0, o)
on = collections.Counter(x.key // 128 for x in o if x.type == "on")
check("3. C major: Maj-family channel 11 plays, min-family channel 12 silent", on[11] > 0 and on[12] == 0, dict(on))
check("3. Note Mute: pad (ch13, muted for root C) silent on C chords", on[13] == 0, dict(on))
o2 = []; e.set_chord(2, "Maj", o2); run(e, 2.5, o2)
on2 = collections.Counter(x.key // 128 for x in o2 if x.type == "on")
check("3. D major: pad (ch13) now plays", on2[13] > 0, dict(on2))
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); e.set_chord(0, "Maj", o); run(e, 0.3, o)
mk = len(o); e.set_chord(9, "min", o)
chg = o[mk:]
check("3. chord Maj->min while ch11 sounds: ch11 notes are cut (not left hanging)", any(x.type == "off" and x.key // 128 == 11 for x in chg), [str(x) for x in chg][:4])

# 4. wait-for-chord (hardware behaviour): only autostart parts before the first chord
e = Engine(); e.load_style(d); o = []; e.set_require_chord(True, o); e.request("MainA"); e.start(); run(e, 2.0, o)
chs = {x.key // 128 for x in o if x.type == "on"}
check("4. wait-for-chord: only autostart channels (drums) sound before a chord", chs <= {8, 9, 11, 12, 13} and 10 not in chs and 9 in chs, sorted(chs))
o3 = []; e.set_chord(0, "Maj", o3); run(e, 2.5, o3)
check("4. wait-for-chord: bass joins once a chord is played", any(x.type == "on" and x.part == "Bass" for x in o3))
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); run(e, 2.0, o)
check("4. default (not waiting): C major assumed, bass sounds immediately", any(x.type == "on" and x.part == "Bass" for x in o))

# 5. unsupported markers end the previous section
check("5. 'Intro D' marker ends Main A: Main A is 2 bars (3840 ticks), not 3", sec.length == 3840, sec.length)
check("5. note from the unsupported section does not leak into Main A", not any(any(ev[2] == 99 for ev in tr) for _, tr in sec.channels))
check("5. unsupported section is not created", "Intro4" not in d.sections and len(d.sections) == 2, sorted(d.sections))

# 6. SubRhythm can be melodic (bank select), drums otherwise
e = Engine(); e.load_style(d)
msub = next(m_ for m_, _ in sec.channels if m_.ch == 8); mrhy = next(m_ for m_, _ in sec.channels if m_.ch == 9)
check("6. SubRhythm with bank MSB 0 is melodic; Rhythm is always drums", (not e.is_drum(msub)) and e.is_drum(mrhy), e.bank[8])
d2 = load("nocasm.sty"); e2 = Engine(); e2.load_style(d2)
check("6. SubRhythm with no bank info defaults to drums", e2.is_drum(Mapping(8, "SubRhythm", "RootFixed", "Bypass", 0, {0}, 11, 0, 127, 1)))

# 7. CC7/CC10/CC11 are live mixer events (not baked into velocity)
e = Engine(); o = []; e.load_style(d); e._apply(d, o)
check("7. _apply emits 48 initial channel events", sum(1 for x in o if x.type == "chan") == 48, sum(1 for x in o if x.type == "chan"))
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); e.set_chord(0, "Maj", o); run(e, 2.5, o)
ex = [x for x in o if x.type == "chan" and x.key == 11 and x.vel == 40]
check("7. CC11 expression fade reaches the mixer as an event", len(ex) > 0 and ex[0].note == 11)
check("7. note velocity stays raw (90), channel level is not baked in", {x.vel for x in o if x.type == "on" and x.key // 128 == 11} == {90})

# 8. SFF2: PPQN 1920, Ctb2 middle range, 100 BPM
d = load("sff2_ctb2.sty")
check("8. SFF2 PPQN 1920 and tempo 100 BPM", d.ppqn == 1920 and round(d.tempo) == 100, (d.ppqn, d.tempo))
ms = {m_.ch: m_ for m_, _ in d.sections["MainA"].channels}
check("8. Ctb2 middle range: bass RootTrans/Melody/HighKey F, chord RootFixed/Chord", (ms[10].ntr, ms[10].ntt, ms[10].hi) == ("RootTrans", "Melody", 5) and (ms[11].ntr, ms[11].ntt) == ("RootFixed", "Chord"), (ms[10].ntr, ms[10].ntt, ms[10].hi))
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); run(e, 7.5, o)
k = [x.t for x in o if x.type == "on" and x.part == "Rhythm"]
check("8. 1920-PPQN timing: bar = 2.4 s at 100 BPM", len(k) >= 3 and abs((k[1] - k[0]) - 2.4) < 0.002, [round(x, 4) for x in k[:3]])

# 9. Cntt overrides NTT; no-CASM defaults
d = load("cntt.sty"); mc = d.sections["MainA"].channels[0][0]
check("9. Cntt value 3 overrides Ctab NTT -> MelodicMinor", mc.ntt == "MelodicMinor", mc.ntt)
e = Engine(); e.load_style(d); o = []; e.request("MainA"); e.start(); e.set_chord(0, "min", o); run(e, 0.3, o)
pcs = sorted(x.note % 12 for x in o if x.type == "on")
check("9. MelodicMinor: major 3rd (E) lowered to minor 3rd (Eb) for a minor chord", 3 in pcs and 4 not in pcs, pcs)
d = load("nocasm.sty"); ms = {m_.ch: m_ for m_, _ in d.sections["MainA"].channels}
check("9. no-CASM defaults: drums autostart, bass RootTrans/Bass with High Key B", ms[9].auto and not ms[10].auto and (ms[10].ntr, ms[10].ntt, ms[10].hi) == ("RootTrans", "Bass", 11))

# 10. Intro lands in the selected Main; sync-armed selection; stop applies pending style
d = load("../app/src/main/assets/demo/DemoPop110.sty") if False else parse_sty(open(os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'demo', 'DemoPop110.sty'), 'rb').read())
e = Engine(); e.load_style(d); o = []; e.request("MainC"); e.request("Intro1"); run(e, 7.0, o)
check("10. Main C selected, then Intro: Intro lands in Main C", [s for _, s in e.log][:1] == ["MainC"], e.log)
e = Engine(); e.load_style(d); o = []; e.request("Intro1"); run(e, 1.0, o); e.request("MainD"); run(e, 6.0, o)
check("10. choosing Main D during the Intro retargets the landing without cutting the Intro", [s for _, s in e.log][:1] == ["MainD"] and e.log[0][0] > 4.0, e.log)
e = Engine(); e.load_style(d); e.sync_start(); e.request("MainB")
check("10. selecting a section while Sync-armed selects it immediately (not queued)", e.current == "MainB" and not e.queue and e.state == "SyncArmed")
e = Engine(); e.load_style(d); e.request("MainA"); e.start(); d2_ = parse_sty(open(os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'demo', 'DemoPop110.sty'), 'rb').read()); d2_.name = "Second"
e.load_style(d2_, live=True); e.stop()
check("10. Stop applies a pending live style swap", e.doc.name == "Second" and e.pending is None)

# 11. Robustness
good = open(os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'demo', 'DemoPop110.sty'), 'rb').read()
def raises(b):
    try: parse_sty(b); return False
    except Exception: return True
check("11. garbage input rejected cleanly", raises(b"not a midi file at all"))
bad=[]
for n in range(0, len(good), 97):
    try: parse_sty(good[:n])
    except (AssertionError, struct.error, IndexError, KeyError, StopIteration): pass
    except Exception as ex: bad.append((n, type(ex).__name__))
check("11. 60+ truncation points: only clean parse failures, nothing else", not bad, bad[:3])
cut = good[:len(good) - 40]
try: parse_sty(cut); okc = True
except Exception: okc = False
check("11. truncated CASM tail does not lose the style (falls back to defaults)", okc)
nomark = T.wrap(T.g.Track().encode() if False else bytes([0, 0xFF, 0x2F, 0]), 96)
check("11. style with no section markers is rejected with an error", raises(nomark))

print("\n%s" % ("ALL AUDIT CHECKS PASSED" if fails == 0 else f"{fails} AUDIT CHECK(S) FAILED")); sys.exit(1 if fails else 0)
