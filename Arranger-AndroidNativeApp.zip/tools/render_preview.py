#!/usr/bin/env python3
"""
Renders a scripted performance of the demo .sty (chord changes, variation
change with auto-fill, break, ending) through a numpy PORT of the Kotlin
synthesizer's recipes, then writes a WAV and prints level statistics.

This is a PREVIEW of the design (parser -> chord/CASM processing -> engine ->
synth), useful for listening on a computer and for checking the output is
non-silent / un-clipped / tempo-aligned. It is NOT the Android app's audio
path: the Kotlin Synth + AudioTrack could not be compiled or run here.
Differences vs the Kotlin synth: no reverb, filter cutoff fixed per note.
"""
import os, sys, wave
import numpy as np
from scipy.signal import lfilter
sys.path.insert(0, os.path.dirname(__file__))
from sty_mirror import *

SR = 44100
STY = os.path.join(os.path.dirname(__file__), '..', 'app', 'src', 'main', 'assets', 'demo', 'DemoPop110.sty')
OUT = sys.argv[1] if len(sys.argv) > 1 else 'preview.wav'
rng = np.random.default_rng(1)

# (w1, w2, detune cents, level2, attack, decay, sustain, release, cutoff, gain) per GM family (program // 8)
FAM = [(1, 2, 4, .25, .004, .9, .25, .35, 4500, .55), (0, 1, 0, .3, .002, .7, 0, .5, 9000, .5), (0, 3, 1200, .35, .01, .05, 1, .08, 6000, .45),
       (2, 1, 6, .3, .002, .6, .2, .3, 3200, .5), (2, 0, -1200, .6, .005, .25, .7, .12, 900, .8), (2, 2, 9, .8, .25, .3, .9, .5, 3500, .4),
       (2, 1, 7, .6, .3, .3, .9, .6, 3000, .4), (2, 3, 5, .3, .06, .2, .75, .15, 3500, .45), (3, 1, 3, .4, .04, .2, .8, .15, 2500, .4),
       (0, 1, 2, .2, .06, .1, .9, .2, 5000, .5), (2, 3, 8, .5, .01, .2, .8, .15, 6000, .4), (2, 2, 11, .8, .5, .4, .85, .9, 2800, .35),
       (1, 2, 15, .3, .1, .5, .6, .5, 3000, .4), (1, 2, 3, .2, .003, .5, .2, .3, 3500, .5), (0, 1, 0, .3, .002, .3, 0, .3, 8000, .5), (0, 1, 0, .2, .01, .5, .5, .4, 4000, .4)]

def blep(ph, inc):
    out = np.zeros_like(ph)
    m = ph < inc; x = ph[m] / inc[m]; out[m] = x + x - x * x - 1
    m = ph > 1 - inc; x = (ph[m] - 1) / inc[m]; out[m] = x * x + x + x + 1
    return out

def osc(w, ph, inc):
    if w == 0: return np.sin(2 * np.pi * ph)
    if w == 1: return 4 * np.abs(ph - .5) - 1
    if w == 2: return 2 * ph - 1 - blep(ph, inc)
    return np.where(ph < .5, 1.0, -1.0) + blep(ph, inc) - blep((ph + .5) % 1, inc)

def melodic(pitch_pts, dur, vel, prog):
    w1, w2, det, l2, A, D, S, R, cut, gain = FAM[min(prog // 8, 15)]
    n = int((dur + R * 1.2) * SR) + 1
    t = np.arange(n) / SR
    # frequency curve with glide on retune points [(time, midi_note), ...]
    f = np.full(n, 440 * 2 ** ((pitch_pts[0][1] - 69) / 12))
    for tt, nn in pitch_pts[1:]:
        tgt = 440 * 2 ** ((nn - 69) / 12); i0 = min(n - 1, int(tt * SR))
        k = np.arange(n - i0); f[i0:] = tgt + (f[i0] - tgt) * np.exp(-k * 0.004)
    inc = f / SR; ph1 = np.cumsum(inc) % 1; inc2 = inc * 2 ** (det / 1200); ph2 = np.cumsum(inc2) % 1
    raw = (osc(w1, ph1, inc) + osc(w2, ph2, inc2) * l2) / (1 + l2)
    v = (vel / 127); v = v * v * .4 + v * .6
    fc = min(cut * (.5 + v * .8) * .8 * (f[0] / 261.6) ** .4, SR * .45)
    a = 1 - np.exp(-2 * np.pi * fc / SR)
    raw = lfilter([a], [1, -(1 - a)], raw)
    env = np.where(t < A, t / max(A, 1e-4), S + (1 - S) * np.exp(-4.6 * (t - A) / max(D, 1e-3)))
    off = int(dur * SR)
    if off < n: env[off:] = env[off] * np.exp(-4.6 * (t[off:] - t[off]) / max(R, 1e-3))
    return raw * env * gain * v

DR = {36: (155, 46, .035, .38, 1, .15, .02, .5, 0, 0, .01, 1), 35: None, 38: (230, 175, .02, .12, .55, .9, .22, .7, .08, 0, .01, .9),
      42: (0, 0, .01, .01, 0, .5, .05, .9, .55, .6, .05, .5), 46: (0, 0, .01, .01, 0, .5, .35, .9, .55, .6, .35, .5),
      49: (0, 0, .01, .01, 0, .8, 1.4, .9, .5, .5, 1.4, .55), 50: (352, 220, .05, .3, .9, .08, .04, .5, 0, 0, .01, .9),
      45: (216, 135, .05, .3, .9, .08, .04, .5, 0, 0, .01, .9), 51: (0, 0, .01, .01, 0, .35, .9, .9, .55, .55, .9, .4),
      70: (0, 0, .01, .01, 0, .7, .08, .85, .5, 0, .01, .5)}
DR[35] = DR[36]
MF = np.array([263, 400, 421, 474, 587, 845.])

def drum(note, vel):
    p = DR.get(note, (0, 0, .01, .01, 0, .6, .05, .7, .2, 0, .01, .5))
    f0, f1, tau, td, tl, nl, nd, hi, lo, ml, md, g = p
    dur = max(td, nd, md) * 1.25 + .02; n = int(dur * SR); t = np.arange(n) / SR; s = np.zeros(n)
    if tl > 0:
        f = f1 + (f0 - f1) * np.exp(-t / tau); s += np.sin(2 * np.pi * np.cumsum(f / SR)) * tl * np.exp(-4.6 * t / td)
    if nl > 0:
        x = rng.uniform(-1, 1, n); x = lfilter([hi], [1, -(1 - hi)], x)
        if lo > 0: x = x - lfilter([lo], [1, -(1 - lo)], x)
        s += x * nl * 2 * np.exp(-4.6 * t / nd)
    if ml > 0:
        m = sum(np.where((t[:, None] * MF[None, :] * np.array([1, 1.5, 1, 1.5, 1, 1.5])[None, :] % 1)[:, k] < .5, 1, -1) for k in range(6))
        s += (m / 6) * ml * .6 * np.exp(-4.6 * t / md)
    return s * g * (vel / 127)

PAN = {"SubRhythm": .58, "Rhythm": .5, "Bass": .5, "Chord1": .4, "Chord2": .62, "Pad": .5, "Phrase1": .55, "Phrase2": .45}
GAIN = {"SubRhythm": .8, "Rhythm": 1.0, "Bass": 1.0, "Chord1": .85, "Chord2": .7, "Pad": .7, "Phrase1": .75, "Phrase2": .7}

def render(events, doc, total):
    L = np.zeros(int(total * SR) + SR * 3); R = np.zeros_like(L)
    open_v, voices = {}, []
    for e in sorted(events, key=lambda x: x.t):
        if e.type == 'on':
            if e.key in open_v: open_v[e.key]['end'] = e.t
            v = dict(start=e.t, end=None, pts=[(0, e.note)], vel=e.vel, part=e.part); open_v[e.key] = v; voices.append(v)
        elif e.type == 'off' and e.key in open_v: open_v.pop(e.key)['end'] = e.t
        elif e.type == 'retune' and e.key in open_v: v = open_v[e.key]; v['pts'].append((e.t - v['start'], e.note))
    for v in voices:
        end = v['end'] if v['end'] is not None else total
        ch = 8 + PARTS.index(v['part'])
        if v['part'] in ('SubRhythm', 'Rhythm'): s = drum(v['pts'][0][1], v['vel'])
        else: s = melodic(v['pts'], max(.02, end - v['start']), v['vel'], doc.prog.get(ch, 0))
        pan = PAN[v['part']]; g = GAIN[v['part']] * .9 * doc.vol.get(ch, 100) / 100
        i = int(v['start'] * SR); j = min(len(L), i + len(s)); s = s[:j - i]
        L[i:j] += s * np.cos(pan * np.pi / 2) * 1.2 * g; R[i:j] += s * np.sin(pan * np.pi / 2) * 1.2 * g
    return np.tanh(L * .9), np.tanh(R * .9)

def main():
    doc = parse_sty(open(STY, 'rb').read())
    e = Engine(); e.load_style(doc); ev = []
    bar = 240 / 110
    script = [(0.0, lambda: (e.set_chord(0, 'Maj', ev), e.request('Intro1'))),
              (4 * bar + .1, lambda: e.set_chord(5, 'Maj', ev)), (5 * bar + .1, lambda: e.set_chord(7, 'Maj', ev)),
              (6 * bar + .1, lambda: e.set_chord(9, 'min', ev)), (7 * bar + .1, lambda: e.request('MainB')),
              (9 * bar + .1, lambda: e.set_chord(0, 'Maj7', ev)), (10 * bar + .1, lambda: e.set_chord(5, 'Maj7', ev)),
              (12 * bar + .1, lambda: e.request('Break')), (13 * bar + .1, lambda: e.request('MainC')),
              (15 * bar + .1, lambda: e.set_chord(7, '7th', ev)), (17 * bar + .1, lambda: e.set_chord(0, 'Maj', ev)),
              (18 * bar + .1, lambda: e.request('Ending1'))]
    blk = 256 / SR; k = 0; sec_log = []
    while True:
        while k < len(script) and e.now >= script[k][0]: script[k][1](); k += 1
        e.advance(blk, ev)
        if e.state == 'Stopped' and k >= len(script) and e.now > 5: break
        if e.now > 80: break
    total = e.now + 1.0
    L, R = render(ev, doc, total)
    pk = max(np.abs(L).max(), np.abs(R).max())
    print(f"events: {len(ev)}  duration: {total:.1f}s  peak: {pk:.3f}  clipped samples: {int((np.abs(L) > .999).sum())}")
    win = SR * 2
    rms = [float(np.sqrt(np.mean(L[i:i + win] ** 2))) for i in range(0, int(total * SR) - win, win)]
    print("RMS per 2s window:", ' '.join(f"{x:.3f}" for x in rms))
    print("section changes:", [(round(t, 2), s) for t, s in e.log])
    print("silent windows (<0.005):", sum(1 for x in rms if x < .005))
    pcm = (np.stack([L, R], 1)[:int(total * SR)] * 30000).astype('<i2')
    with wave.open(OUT, 'wb') as w: w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print("wrote", OUT)

if __name__ == '__main__': main()
