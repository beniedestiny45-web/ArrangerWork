#!/usr/bin/env python3
"""Edge-case styles for the audit tests (NOT bundled in the app)."""
import os, struct, sys
sys.path.insert(0, os.path.dirname(__file__))
import make_demo_sty as g

OUT = os.path.join(os.path.dirname(__file__), 'testdata'); os.makedirs(OUT, exist_ok=True)

def wrap(track, ppqn, casm=b""):
    return b"MThd" + struct.pack('>IHHH', 6, 0, 1, ppqn) + b"MTrk" + struct.pack('>I', len(track)) + track + casm

def csegs(groups):
    body = b""
    for names, ctabs in groups:
        sd = names.encode(); seg = b"Sdec" + struct.pack('>I', len(sd)) + sd + b"".join(ctabs)
        body += b"CSEG" + struct.pack('>I', len(seg)) + seg
    return b"CASM" + struct.pack('>I', len(body)) + body

def ctb2(src, dst, ntr, ntt_new, name, hi=5, chord_mute=b'\xff' * 5, note_mute=b'\xff\xff', rtr=1):
    b = bytearray(47)
    b[0] = src; b[1:9] = name.encode().ljust(8)[:8]; b[9] = dst; b[10] = 1; b[11:13] = note_mute; b[13:18] = chord_mute
    b[18] = 0; b[19] = 2; b[20], b[21] = 0, 127
    b[22:28] = bytes([1, 0, 0, 0, 127, 1]); b[28:34] = bytes([ntr, ntt_new, hi, 0, 127, rtr]); b[34:40] = bytes([1, 0, 0, 0, 127, 1])
    return b"Ctb2" + struct.pack('>I', len(b)) + bytes(b)

def cntt(src, ntt):
    return b"Cntt" + struct.pack('>I', 2) + bytes([src, ntt])

MAJ_FAMILY = bytes([0x04, 0x00, 0x00, 0x00, 0xFF])        # autostart + all Maj types (byte17 = Maj..aug)
MIN_FAMILY = bytes([0x04, 0x00, 0x00, 0xFF, 0x00])        # autostart + all min types (byte16)

def build_chordmute(ppqn=480):
    """ch11 plays only for Maj-family chords, ch12 only for min-family, ch13 not for root C, ch9 drums autostart,
    ch10 bass (no autostart: waits for a chord). Also: unknown 'Intro D' marker between Main A and Fill, a melodic SubRhythm
    (bank 0) and CC11 expression fade, via CASM Ctab and a Ctb2 + Cntt channel."""
    bar = ppqn * 4; t = g.Track()
    t.text(0, "SFF1"); t.meta(0, 0x03, b"Edge Test")
    t.meta(0, 0x51, struct.pack('>I', 500000)[1:]); t.meta(0, 0x58, bytes([4, 2, 24, 8])); t.text(0, "SInt")
    t.add(5, [0xB8, 0, 0], 1); t.add(5, [0xC8, 4], 1)                      # SubRhythm channel: bank 0 (melodic) + program 4
    t.add(5, [0xB9, 0, 120], 1)                                           # Rhythm: drum kit bank
    pos = bar
    t.text(pos, "Main A")
    for b in range(2):
        o = pos + b * bar
        t.note(o, 9, 36, 100, 100); t.note(o + 2 * ppqn, 9, 38, 100, 100)
        t.note(o, 10, 36, 100, bar - 40)                                  # bass, whole bar
        for n in (60, 64, 67): t.note(o, 11, n, 90, bar - 40)             # ch11 chord (Maj family only)
        for n in (60, 63, 67): t.note(o, 12, n, 90, bar - 40)             # ch12 chord (min family only)
        t.note(o, 13, 48, 80, bar - 40)                                   # ch13 pad: muted when root == C
        t.note(o, 8, 72, 90, ppqn)                                        # melodic SubRhythm voice
        t.add(o + ppqn, [0xB0 | 11, 11, 40], 1)                           # CC11 fade on ch11
    pos += 2 * bar
    t.text(pos, "Intro D")                                                # unsupported section: must END Main A
    t.note(pos, 11, 99, 120, ppqn)                                        # this note must NOT leak into Main A
    pos += bar
    t.text(pos, "Ending A"); t.note(pos, 9, 36, 100, 100); pos += bar
    track = t.encode()
    ct = lambda src, dst, ntr, ntt, nm, **k: g.ctab(src, dst, ntr, ntt, nm, **k)
    grp1 = ("Main A,Ending A", [
        ct(8, 8, 1, 0, "SubRhy", note_mute=b'\xff\xff'), ct(9, 9, 1, 0, "Rhythm"),
        ct(10, 10, 0, 3, "Bass", hi=5, chord_mute=bytes([0x00, 0xFF, 0xFF, 0xFF, 0xFF])),   # no autostart bit
        ct(11, 11, 1, 2, "Chord1", chord_mute=MAJ_FAMILY), ct(12, 12, 1, 2, "Chord2", chord_mute=MIN_FAMILY),
        ct(13, 13, 1, 2, "Pad", note_mute=b'\x0f\xfe')])                  # bit0 of byte12 = C cleared -> silent on C chords
    return wrap(track, ppqn, csegs([grp1]))

def build_1920_ctb2():
    ppqn = 1920; bar = ppqn * 4; t = g.Track()
    t.text(0, "SFF2"); t.meta(0, 0x03, b"SFF2 Test"); t.meta(0, 0x51, struct.pack('>I', 600000)[1:]); t.meta(0, 0x58, bytes([4, 2, 24, 8])); t.text(0, "SInt")
    t.text(bar, "Main A")
    for b in range(2):
        o = bar + b * bar
        t.note(o, 9, 36, 100, 200); t.note(o, 10, 36, 100, bar // 2); t.note(o, 11, 60, 90, bar // 2); t.note(o, 11, 64, 90, bar // 2); t.note(o, 11, 67, 90, bar // 2)
    track = t.encode()
    casm = csegs([("Main A", [ctb2(9, 9, 1, 0, "Rhythm"), ctb2(10, 10, 0, 1, "Bass", hi=5), ctb2(11, 11, 1, 2, "Chord1")]), ])
    return wrap(track, ppqn, casm)

def build_cntt():
    ppqn = 480; bar = ppqn * 4; t = g.Track()
    t.text(0, "SFF1"); t.meta(0, 0x03, b"Cntt Test"); t.meta(0, 0x51, struct.pack('>I', 500000)[1:]); t.text(0, "SInt")
    t.text(bar, "Main A")
    for n in (64, 67, 71): t.note(bar, 11, n, 90, bar - 20)               # E G B (source Maj7 notes)
    track = t.encode()
    casm = csegs([("Main A", [g.ctab(11, 11, 1, 2, "Chord1"), cntt(11, 3)])])   # Cntt value 3 = melodic minor
    return wrap(track, ppqn, casm)

def build_nocasm():
    ppqn = 96; bar = ppqn * 4; t = g.Track()
    t.text(0, "SFF1"); t.meta(0, 0x03, b"No CASM"); t.meta(0, 0x51, struct.pack('>I', 500000)[1:]); t.text(0, "SInt")
    t.text(bar, "Main A")
    t.note(bar, 9, 36, 100, 40); t.note(bar, 10, 36, 100, 200); t.note(bar, 11, 60, 90, 300)
    return wrap(t.encode(), ppqn)

if __name__ == '__main__':
    for name, data in (("chordmute.sty", build_chordmute()), ("sff2_ctb2.sty", build_1920_ctb2()), ("cntt.sty", build_cntt()), ("nocasm.sty", build_nocasm())):
        open(os.path.join(OUT, name), 'wb').write(data); print("wrote", name, len(data))
