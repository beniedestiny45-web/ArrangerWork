"""
Executable mirror of the Kotlin core (StyParser / CasmParser / Transposer / StyleEngine), kept in
step with it line for line. The Kotlin could NOT be compiled where it was written, so this runs the
same algorithms in Python to verify the LOGIC. It proves the design, not that the Kotlin compiles,
and it produces no sound.
"""
import math, struct, itertools
from collections import deque

PARTS = ['SubRhythm', 'Rhythm', 'Bass', 'Chord1', 'Chord2', 'Pad', 'Phrase1', 'Phrase2']   # channels 9..16
MARKERS = {"Intro A": "Intro1", "Intro B": "Intro2", "Intro C": "Intro3", "Main A": "MainA", "Main B": "MainB",
           "Main C": "MainC", "Main D": "MainD", "Fill In AA": "FillA", "Fill In BB": "FillB", "Fill In CC": "FillC",
           "Fill In DD": "FillD", "Fill In BA": "Break", "Ending A": "Ending1", "Ending B": "Ending2", "Ending C": "Ending3"}
IGNORED = {"Intro D", "Ending D", "Fill In AB"}
IS_MAIN = lambda s: s in ("MainA", "MainB", "MainC", "MainD")
IS_ENDING = lambda s: s.startswith("Ending")
IS_INTRO = lambda s: s.startswith("Intro")

CT = ["Maj", "Maj6", "Maj7", "Maj7#11", "Maj(9)", "Maj7(9)", "Maj6(9)", "aug", "min", "min6", "min7", "min7b5", "min(9)", "min7(9)",
      "min7(11)", "minMaj7", "minMaj7(9)", "dim", "dim7", "7th", "7sus4", "7b5", "7(9)", "7#11", "7(13)", "7(b9)", "7(b13)", "7(#9)",
      "Maj7aug", "7aug", "1+8", "1+5", "sus4", "1+2+5", "cancel"]
TONES = {"Maj": {0, 4, 7}, "Maj6": {0, 4, 7, 9}, "Maj7": {0, 4, 7, 11}, "Maj7#11": {0, 4, 6, 7, 11}, "Maj(9)": {0, 2, 4, 7},
         "Maj7(9)": {0, 2, 4, 7, 11}, "Maj6(9)": {0, 2, 4, 7, 9}, "aug": {0, 4, 8}, "min": {0, 3, 7}, "min6": {0, 3, 7, 9},
         "min7": {0, 3, 7, 10}, "min7b5": {0, 3, 6, 10}, "min(9)": {0, 2, 3, 7}, "min7(9)": {0, 2, 3, 7, 10}, "min7(11)": {0, 3, 5, 7, 10},
         "minMaj7": {0, 3, 7, 11}, "minMaj7(9)": {0, 2, 3, 7, 11}, "dim": {0, 3, 6}, "dim7": {0, 3, 6, 9}, "7th": {0, 4, 7, 10},
         "7sus4": {0, 5, 7, 10}, "7b5": {0, 4, 6, 10}, "7(9)": {0, 2, 4, 7, 10}, "7#11": {0, 4, 6, 7, 10}, "7(13)": {0, 4, 7, 9, 10},
         "7(b9)": {0, 1, 4, 7, 10}, "7(b13)": {0, 4, 7, 8, 10}, "7(#9)": {0, 3, 4, 7, 10}, "Maj7aug": {0, 4, 8, 11}, "7aug": {0, 4, 8, 10},
         "1+8": {0}, "1+5": {0, 7}, "sus4": {0, 5, 7}, "1+2+5": {0, 2, 7}, "cancel": {0}}
CHORD_BITS = [["sus4", "1+2+5", "", "", "", "", "", ""],
              ["7(13)", "7(b9)", "7(b13)", "7(#9)", "Maj7aug", "7aug", "1+8", "1+5"],
              ["minMaj7(9)", "dim", "dim7", "7th", "7sus4", "7b5", "7(9)", "7#11"],
              ["min", "min6", "min7", "min7b5", "min(9)", "min7(9)", "min7(11)", "minMaj7"],
              ["Maj", "Maj6", "Maj7", "Maj7#11", "Maj(9)", "Maj7(9)", "Maj6(9)", "aug"]]

class Mapping:
    def __init__(self, ch, part, ntr, ntt, root, tones, hi, lo, hil, rtr, note_mask=0xFFF, plays=None, auto=True):
        self.ch, self.part, self.ntr, self.ntt, self.root, self.tones = ch, part, ntr, ntt, root, frozenset(tones)
        self.hi, self.lo, self.hil, self.rtr, self.note_mask, self.plays, self.auto = hi, lo, hil, rtr, note_mask, plays, auto
    def key(self): return (self.ch, self.part, self.ntr, self.ntt, self.root, self.tones, self.hi, self.lo, self.hil)

class Section:
    def __init__(self, sid, start, length): self.id, self.start, self.length, self.tempo_scale, self.channels = sid, start, length, 1.0, []

class Doc:
    def __init__(self): self.name, self.tempo, self.ppqn, self.num, self.den = "Untitled", 120.0, 96, 4, 4; self.sections, self.prog, self.vol, self.pan, self.bank = {}, {}, {}, {}, {}

def u32(b, o): return struct.unpack_from('>I', b, o)[0]
def u16(b, o): return struct.unpack_from('>H', b, o)[0]

def varlen(b, p, end):
    v = 0
    for _ in range(4):
        if p >= end: break
        c = b[p]; p += 1; v = (v << 7) | (c & 0x7F)
        if not c & 0x80: break
    return v, p

def decode_track(b, start, end):
    ev, pos, ab, running = [], start, 0, 0
    while pos < end:
        d, pos = varlen(b, pos, end); ab += d
        if pos >= end: break
        sb = b[pos]
        if sb == 0xFF:
            pos += 1; typ = b[pos]; pos += 1; l, pos = varlen(b, pos, end)
            if pos + l > end: break
            if typ == 0x51 and l >= 3: ev.append((ab, 0xFF, int.from_bytes(b[pos:pos+3], 'big'), 0, typ, None))
            elif typ == 0x58 and l >= 2: ev.append((ab, 0xFF, b[pos], b[pos+1], typ, None))
            elif typ in (1, 2, 3, 6): ev.append((ab, 0xFF, 0, 0, typ, b[pos:pos+l].decode('latin-1')))
            else: ev.append((ab, 0xFF, 0, 0, typ, None))
            pos += l
            if typ == 0x2F: break
            continue
        if sb in (0xF0, 0xF7): pos += 1; l, pos = varlen(b, pos, end); pos += l; continue
        if sb & 0x80: status = sb; pos += 1
        else: status = running
        if status == 0: break
        running = status
        two = (status & 0xF0) not in (0xC0, 0xD0)
        if pos >= end: break
        d1 = b[pos]; pos += 1; d2 = 0
        if two:
            if pos >= end: break
            d2 = b[pos]; pos += 1
        ev.append((ab, status, d1, d2, -1, None))
    return ev

def ctab_ntt(v): return {0: "Bypass", 1: "Melody", 2: "Chord", 3: "Bass", 4: "MelodicMinor", 5: "HarmonicMinor"}.get(v & 0x7F, "Chord")
def cntt_ntt(v):
    v &= 0x7F
    return "Bypass" if v == 0 else "Melody" if v == 1 else "Chord" if v == 2 else "MelodicMinor" if v in (3, 4, 7, 8, 9, 10) else "HarmonicMinor" if v in (5, 6) else "Chord"

def common(d, o):
    src = d[o] & 15; dest = d[o + 9]; part = PARTS[dest - 8] if 8 <= dest <= 15 else "Chord1"
    note_mask = d[o + 12] | ((d[o + 11] & 0x0F) << 8)
    plays = set()
    for bi in range(5):
        for bit in range(8):
            n = CHORD_BITS[bi][bit]
            if n and (d[o + 13 + bi] >> bit) & 1: plays.add(n)
    auto = bool((d[o + 13] >> 2) & 1)
    root = min(d[o + 18], 11); ct = CT[min(d[o + 19], len(CT) - 1)]
    return src, part, root, TONES[ct], note_mask, plays, auto

def parse_casm(data):
    out, pos = {}, 0
    while pos + 8 <= len(data) and data[pos:pos+4] == b"CSEG":
        ln = u32(data, pos + 4); s, e = pos + 8, pos + 8 + ln; p = s
        if data[p:p+4] == b"Sdec":
            sl = u32(data, p + 4); names = data[p+8:p+8+sl].decode('latin-1').split(','); p += 8 + sl
            maps = []
            while p + 8 <= e:
                cid, cl = data[p:p+4], u32(data, p + 4); bs = p + 8
                if cid == b"Ctab" and cl >= 26:
                    src, part, root, tones, nm, plays, auto = common(data, bs)
                    maps.append(Mapping(src, part, "RootTrans" if data[bs+20] == 0 else "RootFixed", ctab_ntt(data[bs+21]), root, tones,
                                        min(data[bs+22], 11), data[bs+23], data[bs+24], data[bs+25], nm, plays, auto))
                elif cid == b"Ctb2" and cl >= 34:
                    src, part, root, tones, nm, plays, auto = common(data, bs); s2 = bs + 28
                    ntr = {0: "RootTrans", 2: "Guitar"}.get(data[s2], "RootFixed")
                    maps.append(Mapping(src, part, ntr, cntt_ntt(data[s2+1]), root, tones, min(data[s2+2], 11), data[s2+3], data[s2+4], data[s2+5], nm, plays, auto))
                elif cid == b"Cntt" and cl >= 2:
                    ch = data[bs] & 15
                    for i in range(len(maps) - 1, -1, -1):
                        if maps[i].ch == ch: maps[i].ntt = cntt_ntt(data[bs+1]); break
                p = bs + cl
            for n in names:
                sid = MARKERS.get(n.strip())
                if sid: out.setdefault(sid, []).extend(maps)
        pos = e
    return out

def parse_sty(b):
    doc = Doc()
    assert b[:4] == b"MThd", "missing MThd"
    hl = u32(b, 4); doc.ppqn = u16(b, 12)
    pos = 8 + hl; assert b[pos:pos+4] == b"MTrk"
    tl = u32(b, pos + 4); ts, te = pos + 8, min(pos + 8 + tl, len(b))
    events = decode_track(b, ts, te); pos = ts + tl; casm = None
    while pos + 8 <= len(b):
        cid, cl = b[pos:pos+4], u32(b, pos + 4)
        if pos + 8 + cl > len(b): break
        if cid == b"CASM": casm = b[pos+8:pos+8+cl]
        pos += 8 + cl
    tempos, markers = [], []
    for (t, st, d1, d2, mt, tx) in events:
        if st != 0xFF: continue
        if mt == 0x51 and d1 > 0: tempos.append((t, d1))
        elif mt == 0x58 and d1 > 0 and doc.num == 4 and doc.den == 4: doc.num, doc.den = d1, 1 << min(d2, 6)
        elif mt in (1, 3, 6) and tx is not None: markers.append((t, tx))
    base = tempos[0][1] if tempos else 500000; doc.tempo = 60_000_000 / base
    i = next((k for k, m in enumerate(markers) if m[1].startswith("SFF")), -1)
    if i >= 0 and i + 1 < len(markers) and markers[i+1][1].strip() not in MARKERS and markers[i+1][1] != "SInt": doc.name = markers[i+1][1].strip()
    hits = sorted((t, MARKERS.get(x.strip())) for t, x in markers if x.strip() in MARKERS or x.strip() in IGNORED)
    assert any(h[1] for h in hits), "no section markers"
    end_tick = max(e[0] for e in events)
    first = hits[0][0]
    for (t, st, d1, d2, mt, tx) in events:
        if t >= first: break
        ch, hi = st & 15, st & 0xF0
        if hi == 0xC0: doc.prog[ch] = d1
        if hi == 0xB0 and d1 == 0: doc.bank[ch] = d2
        if hi == 0xB0 and d1 == 7: doc.vol[ch] = d2
        if hi == 0xB0 and d1 == 10: doc.pan[ch] = d2
    cmap = parse_casm(casm) if casm else {}
    for k, (start, sid) in enumerate(hits):
        if sid is None: continue
        end = hits[k+1][0] if k + 1 < len(hits) else end_tick
        sec = Section(sid, start, max(1, end - start))
        micros = next((m for (t, m) in reversed(tempos) if t <= start), base); sec.tempo_scale = base / micros
        rng = [e for e in events if start <= e[0] < end and (e[1] & 0xF0) in range(0x80, 0xE1)]
        for ch in sorted({e[1] & 15 for e in rng}):
            m = next((x for x in cmap.get(sid, []) if x.ch == ch), None)
            if m is None:
                part = PARTS[ch - 8] if 8 <= ch <= 15 else "Chord1"
                ntr, ntt = {"SubRhythm": ("RootFixed", "Bypass"), "Rhythm": ("RootFixed", "Bypass"), "Bass": ("RootTrans", "Bass"),
                            "Chord1": ("RootFixed", "Chord"), "Chord2": ("RootFixed", "Chord"), "Pad": ("RootFixed", "Chord"),
                            "Phrase1": ("RootTrans", "Melody"), "Phrase2": ("RootTrans", "Melody")}[part]
                m = Mapping(ch, part, ntr, ntt, 0, TONES["Maj7"], 11, 0, 127, 1, 0xFFF, None, part in ("SubRhythm", "Rhythm"))
            sec.channels.append((m, sorted([(e[0] - start, e[1], e[2], e[3]) for e in rng if e[1] & 15 == ch], key=lambda x: x[0])))
        doc.sections[sid] = sec
    return doc

# ------------------------------------------------------------------ transposer (documented rules)
def nearest(a, b):
    d = (b - a) % 12
    return d - 12 if d > 6 else d

def root_trans_shift(m, troot):
    rel = (troot - m.root) % 12
    return rel - 12 if troot > max(0, min(m.hi, 11)) else rel

def important(tones):
    s = sorted(tones)
    return s if len(s) <= 3 else [x for x in s if x != 0] if len(s) == 4 else [x for x in s if x not in (0, 7)]

def fixed_table(m, troot, ttones):
    follow = nearest(m.root, troot); table = [follow] * 12
    s, d = important(m.tones), important(ttones or {0, 4, 7})
    if not s or not d: return table
    sp = [(m.root + x) % 12 for x in s]; dp = [(troot + x) % 12 for x in d]
    best, bc = None, 10**9
    def search(i, used, cost, cur):
        nonlocal best, bc
        if cost >= bc: return
        if i == len(s): best, bc = list(cur), cost; return
        all_used = bin(used).count('1') >= len(d)
        for j in range(len(d)):
            if not all_used and (used >> j) & 1: continue
            cur.append(j); search(i + 1, used | (1 << j), cost + abs(nearest(sp[i], dp[j])), cur); cur.pop()
    search(0, 0, 0, [])
    for i in range(len(s)): table[s[i] % 12] = nearest(sp[i], dp[best[i]])
    if len(m.tones) >= 5:
        table[0] = nearest(m.root, troot)
        if 7 in ttones: table[7] = nearest((m.root + 7) % 12, (troot + 7) % 12)
    return table

def clamp(n, m):
    if n < 0 or n > 127: return None
    if 0 <= m.lo <= 127 and 0 <= m.hil <= 127 and m.hil - m.lo >= 11:
        while n < m.lo: n += 12
        while n > m.hil: n -= 12
        if n < m.lo or n > m.hil: return None
    return n

def transpose_note(note, m, troot, ttones, tminor, sminor, table=None):
    if m.ntt == "Bypass": return clamp(note, m)
    if m.ntt in ("MelodicMinor", "HarmonicMinor"):
        r, pc = note, (note - m.root) % 12
        if sminor != tminor:
            if pc == 4 and tminor: r -= 1
            elif pc == 3 and not tminor: r += 1
            elif m.ntt == "HarmonicMinor":
                if pc == 9 and tminor: r -= 1
                elif pc == 8 and not tminor: r += 1
        return clamp(r + (root_trans_shift(m, troot) if m.ntr == "RootTrans" else nearest(m.root, troot)), m)
    if m.ntr == "RootTrans": return clamp(note + root_trans_shift(m, troot), m)
    table = table or fixed_table(m, troot, ttones)
    return clamp(note + table[(note - m.root) % 12], m)

# ------------------------------------------------------------------ engine
class Ev:
    __slots__ = ("t", "type", "key", "note", "vel", "part", "section")
    def __init__(self, t, type, key, note, vel, part, section): self.t, self.type, self.key, self.note, self.vel, self.part, self.section = t, type, key, note, vel, part, section
    def __repr__(self): return f"{self.type}({self.part} n={self.note} k={self.key} t={self.t:.3f} {self.section})"

class Engine:
    def __init__(self):
        self.doc = None; self.pending = None; self.state = "Stopped"; self.current = "MainA"; self.last_main = "MainA"
        self.queue = deque(); self.tempo = 120.0; self.locked = False; self.transpose = 0; self.auto_fill = True
        self.default_chord = (0, "Maj", False); self.chord = self.default_chord; self.chord_user = False; self.require_chord = False
        self.tick = 0; self.last_emitted = -1; self.acc = 0.0; self.cursors = {}
        self.vol = [100]*16; self.expr = [127]*16; self.bank = [-1]*16; self.active = {}; self.now = 0.0; self.log = []; self.tables = {}
    def set_require_chord(self, on, out):
        self.require_chord = on
        if not self.chord_user: self.chord = None if on else self.default_chord; self.tables.clear()
        self._retarget(out)
    def load_style(self, doc, live=False):
        if live and self.state in ("Playing",): self.pending = doc; return
        self._apply(doc, [])
    def _apply(self, doc, out):
        self._release_all(out, 0.0); self.doc = doc; self.tables.clear()
        if not self.locked: self.tempo = doc.tempo
        for ch in range(16):
            self.vol[ch] = doc.vol.get(ch, 100); self.bank[ch] = doc.bank.get(ch, -1); self.expr[ch] = 127
            for cc, v in ((7, self.vol[ch]), (10, doc.pan.get(ch, 64)), (11, 127)): out.append(Ev(self.now, "chan", cc, ch, v, "", ""))
        self.current = self.current if self.current in doc.sections else next(s for s in ("MainA", "MainB", "MainC", "MainD") if s in doc.sections)
        if IS_MAIN(self.current): self.last_main = self.current
        self.tick = 0; self.last_emitted = -1; self.cursors = {}; self.acc = 0.0; self.queue.clear()
    def start(self): self.state = "Playing"; self._reset()
    def sync_start(self): self.state = "SyncArmed"; self._reset()
    def stop(self, out=None):
        out = out if out is not None else []
        self._release_all(out, 0.0); self.state = "Stopped"; self._reset(); self.queue.clear()
        if self.pending: doc, tp = self.pending, self.tempo; self.pending = None; self._apply(doc, out); self.tempo = tp if self.locked else self.tempo
    def _reset(self): self.tick = 0; self.last_emitted = -1; self.cursors = {}; self.acc = 0.0
    def request(self, sid):
        d = self.doc
        if sid not in d.sections: return
        if self.state in ("Stopped", "SyncArmed"):
            self.current = sid
            if IS_MAIN(sid): self.last_main = sid
            self._reset()
            if self.state == "Stopped" and IS_INTRO(sid): self.state = "Playing"
            return
        if IS_INTRO(self.current) and IS_MAIN(sid): self.last_main = sid; return
        self.queue.clear()
        fill = {"MainA": "FillA", "MainB": "FillB", "MainC": "FillC", "MainD": "FillD"}
        if IS_MAIN(sid) and self.auto_fill and IS_MAIN(self.current) and sid != self.current and fill[sid] in d.sections: self.queue.append(fill[sid])
        self.queue.append(sid)
    def set_chord(self, root, typ, out):
        minor = typ.startswith("min") and not typ.startswith("minMaj") or typ == "min"
        changed = self.chord is None or self.chord[:2] != (root, typ)
        self.chord = (root, typ, minor); self.chord_user = True
        if changed: self.tables.clear()
        if self.state == "SyncArmed": self.state = "Playing"; self._reset()
        if changed: self._retarget(out)
    # ---- helpers
    def is_drum(self, m): return m.part == "Rhythm" or (m.part == "SubRhythm" and (self.bank[m.ch] < 0 or self.bank[m.ch] in (120, 126, 127)))
    def allowed(self, m):
        if self.chord is None: return m.auto
        root, typ, _ = self.chord
        if not (m.note_mask >> root) & 1: return False
        return m.plays is None or typ in m.plays
    def _tr(self, m, note):
        if self.is_drum(m): return note
        sminor = 3 in m.tones and 4 not in m.tones
        if self.chord: root, typ, minor = self.chord; tones = TONES.get(typ, {0, 4, 7})
        else: root, tones, minor = m.root, m.tones, sminor
        table = None
        if m.ntr != "RootTrans" and m.ntt not in ("Bypass", "MelodicMinor", "HarmonicMinor"):
            table = self.tables.get(m.key())
            if table is None: table = self.tables[m.key()] = fixed_table(m, root, tones)
        t = transpose_note(note, m, root, tones, minor, sminor, table)
        if t is None: return None
        r = t + self.transpose
        return r if 0 <= r <= 127 else None
    def _emit(self, out, t, typ, key, note, vel, part): out.append(Ev(self.now + t, typ, key, note, vel, part, self.current))
    def _retarget(self, out):
        for key, (outn, vel, m) in list(self.active.items()):
            if not self.allowed(m): self._emit(out, 0, "off", key, outn, 0, m.part); del self.active[key]; continue
            if m.ntt == "Bypass": continue
            nw = self._tr(m, key & 127)
            if nw is None: self._emit(out, 0, "off", key, outn, 0, m.part); del self.active[key]; continue
            if nw == outn: continue
            if m.rtr == 0: self._emit(out, 0, "off", key, outn, 0, m.part); del self.active[key]
            elif m.rtr in (3, 4): self._emit(out, 0, "off", key, outn, 0, m.part); self._emit(out, 0, "on", key, nw, vel, m.part); self.active[key] = (nw, vel, m)
            else: self._emit(out, 0, "retune", key, nw, 0, m.part); self.active[key] = (nw, vel, m)
    def _release_all(self, out, t):
        for key, (outn, vel, m) in list(self.active.items()): self._emit(out, t, "off", key, outn, 0, m.part)
        self.active.clear()
    def _switch(self, sid, out, t):
        if sid not in self.doc.sections: return
        self._release_all(out, t); self.current = sid
        if IS_MAIN(sid): self.last_main = sid
        self.tick = 0; self.last_emitted = -1; self.cursors = {}; self.log.append((self.now + t, sid))
    def _bar(self): d = self.doc; return max(1, d.ppqn * 4 * d.num // d.den)
    def _emit_range(self, sec, frm, to, playhead, base, spt, out):
        for ci, (m, evs) in enumerate(sec.channels):
            c = self.cursors.get(ci, 0)
            while c < len(evs) and evs[c][0] <= to:
                tick, st, d1, d2 = evs[c]
                if tick > frm:
                    t = base + (tick - playhead) * spt; key = m.ch * 128 + (d1 & 127); hi = st & 0xF0
                    if hi == 0x90 and d2 > 0:
                        o = self._tr(m, d1) if self.allowed(m) else None
                        if o is not None:
                            if key in self.active: self._emit(out, t, "off", key, self.active[key][0], 0, m.part)
                            self.active[key] = (o, d2, m); self._emit(out, t, "on", key, o, d2, m.part)
                    elif hi == 0x80 or (hi == 0x90 and d2 == 0):
                        if key in self.active: self._emit(out, t, "off", key, self.active.pop(key)[0], 0, m.part)
                    elif hi == 0xB0:
                        if d1 == 0: self.bank[m.ch] = d2
                        elif d1 in (7, 10, 11):
                            if d1 == 7: self.vol[m.ch] = d2
                            if d1 == 11: self.expr[m.ch] = d2
                            out.append(Ev(self.now + t, "chan", d1, m.ch, d2, m.part, self.current))
                c += 1
            self.cursors[ci] = c
    def _finish_pending(self, out):
        doc, tp = self.pending, self.tempo; self.pending = None; self._apply(doc, out)
        if self.locked: self.tempo = tp
    def _at_bar(self, out, t):
        if self.pending: self._finish_pending(out); return
        if self.queue: self._switch(self.queue.popleft(), out, t)
    def _at_end(self, sec, out, t):
        d = self.doc
        if self.pending: self._finish_pending(out); return
        if self.queue: self._switch(self.queue.popleft(), out, t); return
        if IS_MAIN(sec.id): self._release_all(out, t); self._reset(); return
        if IS_ENDING(sec.id): self._release_all(out, t); self.state = "Stopped"; self._reset()
        elif IS_INTRO(sec.id):
            tgt = self.last_main if self.last_main in d.sections else "MainA" if "MainA" in d.sections else next((s for s in d.sections if IS_MAIN(s)), self.last_main)
            self._switch(tgt, out, t)
        else:
            tgt = {"FillA": "MainA", "FillB": "MainB", "FillC": "MainC", "FillD": "MainD"}.get(sec.id, self.last_main)
            self._switch(tgt if tgt in d.sections else self.last_main, out, t)
    def advance(self, dt, out):
        d = self.doc
        if d is None or self.state != "Playing": self.now += dt; return
        rem, cursor, guard = dt, 0.0, 0
        while rem > 1e-9 and guard < 10000:
            guard += 1
            sec = d.sections[self.current]
            tps = self.tempo * sec.tempo_scale * d.ppqn / 60.0; spt = 1.0 / tps
            avail = self.acc + rem * tps; whole = math.floor(avail)
            if whole <= 0: self.acc = avail; break
            ln = max(1, sec.length); bar = self._bar(); limit, bb = ln, False
            if self.queue or self.pending:
                nb = (self.tick // bar + 1) * bar
                if nb < limit: limit, bb = nb, True
            step = min(whole, max(1, limit - self.tick))
            self._emit_range(sec, self.last_emitted, self.tick + step, self.tick, cursor - self.acc * spt, spt, out)
            self.last_emitted = self.tick + step; self.tick += step
            left = avail - step
            if left < 1.0: self.acc = left; rem = 0.0
            else: self.acc = 0.0; rem = left / tps
            cursor = dt - rem
            if self.tick >= limit:
                if bb and self.tick < ln: self._at_bar(out, cursor)
                else: self._at_end(sec, out, cursor)
                if self.state == "Stopped": break
        self.now += dt
