package com.yourcompany.arrangerworkstation.core

/**
 * The eight accompaniment channels of a style-based arranger, in their
 * documented MIDI channel order (channel 9 = SubRhythm .. channel 16 =
 * Phrase2). Source: publicly available community documentation of the
 * .sty container (Wierzba/Bedesem, "Style Files - Introduction and
 * Details"); see docs/STY_NATIVE_FORMAT.md.
 */
enum class PartId(val midiChannel1to16: Int, val displayName: String) {
    SubRhythm(9, "Sub Rhythm"),
    Rhythm(10, "Rhythm"),
    Bass(11, "Bass"),
    Chord1(12, "Chord 1"),
    Chord2(13, "Chord 2"),
    Pad(14, "Pad"),
    Phrase1(15, "Phrase 1"),
    Phrase2(16, "Phrase 2");

    val isDrum: Boolean get() = this == SubRhythm || this == Rhythm

    companion object {
        fun forDestChannel(ch1to16: Int): PartId? = values().firstOrNull { it.midiChannel1to16 == ch1to16 }
    }
}

enum class SectionId(val displayName: String) {
    Intro1("Intro 1"), Intro2("Intro 2"), Intro3("Intro 3"),
    MainA("Main A"), MainB("Main B"), MainC("Main C"), MainD("Main D"),
    FillA("Fill A"), FillB("Fill B"), FillC("Fill C"), FillD("Fill D"),
    Break("Break"),
    Ending1("Ending 1"), Ending2("Ending 2"), Ending3("Ending 3");

    val isMain: Boolean get() = this == MainA || this == MainB || this == MainC || this == MainD
    val isEnding: Boolean get() = this == Ending1 || this == Ending2 || this == Ending3
    val isIntro: Boolean get() = this == Intro1 || this == Intro2 || this == Intro3
    val loops: Boolean get() = isMain

    companion object {
        /** Exact (case/space-sensitive) marker strings documented for style
         * files. "Fill In BA" represents the Break section. */
        /** Documented markers this app does not play (PSR-2000 Intro D / Ending D, PSR-8000 Fill In AB).
         * They must still END the preceding section, otherwise their notes would leak into it. */
        private fun cleanMarker(text: String): String = text.trim { it == '\u0000' || it.isWhitespace() }
        fun isIgnoredMarker(text: String): Boolean = cleanMarker(text) in setOf("Intro D", "Ending D", "Fill In AB")

        fun fromMarkerText(text: String): SectionId? = when (cleanMarker(text)) {
            "Intro A" -> Intro1; "Intro B" -> Intro2; "Intro C" -> Intro3
            "Main A" -> MainA; "Main B" -> MainB; "Main C" -> MainC; "Main D" -> MainD
            "Fill In AA" -> FillA; "Fill In BB" -> FillB; "Fill In CC" -> FillC; "Fill In DD" -> FillD
            "Fill In BA" -> Break
            "Ending A" -> Ending1; "Ending B" -> Ending2; "Ending C" -> Ending3
            else -> null
        }
    }
}

/** Note Transposition Rule: rigid block shift (RootTrans) vs per-note
 * re-voicing to the nearest chord tone (RootFixed). */
enum class Ntr { RootTrans, RootFixed, Guitar }

/** Note Transposition Table family. */
enum class Ntt { Bypass, Melody, Chord, Bass, MelodicMinor, HarmonicMinor }

/** Retrigger Rule: what a sounding note does across a chord change. */
enum class Rtr { Stop, PitchShift, PitchShiftToRoot, Retrigger, RetriggerToRoot, NoteGenerator }

/** Fully resolved per-source-channel rules for one section. */
data class ChannelMapping(
    val sourceChannel0to15: Int,
    val destPart: PartId,
    val ntr: Ntr,
    val ntt: Ntt,
    val sourceRootPitchClass: Int,
    val sourceChordTones: Set<Int>,
    val highKeyPitchClass: Int,      // 0 = no limit
    val noteLowLimit: Int,
    val noteHighLimit: Int,
    val rtr: Rtr,
    /** Note Mute: bit n (0 = C .. 11 = B) set => this channel PLAYS when the chord root is pitch class n. */
    val noteMuteMask: Int = 0xFFF,
    /** Chord Mute: chord-type names for which this channel plays; null = plays for every chord type. */
    val chordPlays: Set<String>? = null,
    /** Chord Mute "autostart" bit: channel plays before the first chord is entered. */
    val autoStart: Boolean = true,
)

/** One playable channel within a section; events are section-relative. */
class ChannelTrack(val mapping: ChannelMapping) {
    val events: MutableList<MidiEvent> = mutableListOf()
}

class StyleSection(val id: SectionId, val startTick: Long, val lengthTicks: Long) {
    /** Tempo ratio vs the style's base tempo (the half-bar-fill trick doubles tempo for a measure). */
    var tempoScale: Double = 1.0
    val channels: MutableList<ChannelTrack> = mutableListOf()
    val loops: Boolean get() = id.loops
}

data class StyleMeta(
    var name: String = "Untitled Style",
    var tempoBpm: Double = 120.0,
    var ppqn: Int = 96,
    var numerator: Int = 4,
    var denominator: Int = 4,
    var copyright: String = "",
)

class StyleDocument {
    val meta = StyleMeta()
    val sections: MutableMap<SectionId, StyleSection> = mutableMapOf()
    // Defaults captured from the setup measure (before the first section).
    val initialProgramByChannel: MutableMap<Int, Int> = mutableMapOf()
    val initialVolumeByChannel: MutableMap<Int, Int> = mutableMapOf()   // CC7
    val initialPanByChannel: MutableMap<Int, Int> = mutableMapOf()      // CC10
    val initialBankMsbByChannel: MutableMap<Int, Int> = mutableMapOf()  // CC0 (drum kits use MSB 120/126/127)
}
