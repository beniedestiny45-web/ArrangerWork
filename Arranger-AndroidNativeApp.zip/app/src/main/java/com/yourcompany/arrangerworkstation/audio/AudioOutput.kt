package com.yourcompany.arrangerworkstation.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Process
import com.yourcompany.arrangerworkstation.core.EventBuffer
import com.yourcompany.arrangerworkstation.core.MixerState
import com.yourcompany.arrangerworkstation.core.StyleEngine

/**
 * Native low-latency PCM output. A dedicated max-priority thread loops:
 *   engine.advance(blockSeconds) -> sample-accurate events
 *   synth.render(...)            -> 16-bit stereo PCM
 *   AudioTrack.write(...)        -> device speaker / headphones
 * so MIDI events are scheduled against the tempo clock and rendered to
 * real audio, never "played back" sequentially from a file. No WebView,
 * so browser autoplay policies do not apply; no microphone permission is
 * needed because this app never records.
 */
class AudioOutput(
    private val context: Context,
    private val engine: StyleEngine,
    private val mixer: MixerState,
) {
    val sampleRate: Int = AudioTrack.getNativeOutputSampleRate(AudioManager.STREAM_MUSIC).let { if (it in 8000..192000) it else 48000 }
    val synth = Synth(sampleRate, mixer)

    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null
    @Volatile private var duck = 1f

    /** The system reports under-runs; surfaced for the UI/diagnostics. */
    @Volatile var underruns: Int = 0; private set
    @Volatile var started: Boolean = false; private set

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> engine.stop()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> engine.stop()
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> duck = 0.3f
            AudioManager.AUDIOFOCUS_GAIN -> duck = 1f
        }
        Unit
    }

    fun start() {
        if (running) return
        requestFocus()
        val channel = AudioFormat.CHANNEL_OUT_STEREO
        val encoding = AudioFormat.ENCODING_PCM_16BIT
        val minBytes = AudioTrack.getMinBufferSize(sampleRate, channel, encoding).coerceAtLeast(2048)
        val blockFrames = 256
        val bufferBytes = maxOf(minBytes, blockFrames * 4 * 4)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val format = AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(channel).setEncoding(encoding).build()
        val builder = AudioTrack.Builder()
            .setAudioAttributes(attrs)
            .setAudioFormat(format)
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        val t = builder.build()
        track = t
        running = true
        t.play()
        started = true

        thread = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val events = EventBuffer(2048)
            val pcm = ShortArray(blockFrames * 2)
            val dt = blockFrames.toDouble() / sampleRate
            var lastUnderruns = 0
            while (running) {
                events.clear()
                engine.advance(dt, events)
                synth.render(pcm, blockFrames, events)
                if (duck < 1f) for (i in pcm.indices) pcm[i] = (pcm[i] * duck).toInt().toShort()
                val written = t.write(pcm, 0, pcm.size)
                if (written < 0) break
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val u = t.underrunCount
                    if (u != lastUnderruns) { underruns = u; lastUnderruns = u }
                }
            }
        }, "ArrangerAudio").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(500)
        thread = null
        track?.let { try { it.stop() } catch (e: IllegalStateException) {}; it.release() }
        track = null
        started = false
        abandonFocus()
    }

    private fun requestFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setOnAudioFocusChangeListener(focusListener)
                .build()
            focusRequest = req
            audioManager.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
    }

    private fun abandonFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        else {
            @Suppress("DEPRECATION")
            audioManager.abandonAudioFocus(focusListener)
        }
    }
}
