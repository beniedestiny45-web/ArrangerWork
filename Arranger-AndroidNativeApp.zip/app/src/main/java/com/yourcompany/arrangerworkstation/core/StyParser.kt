package com.yourcompany.arrangerworkstation.core

/**
 * Parses a ".sty" style-arranger container: a Standard MIDI File (Type 0,
 * one track) followed by big-endian-length-prefixed extra chunks (CASM /
 * OTSc / FNRc / MHhd). Section boundaries are marker (text/marker meta)
 * events inside the single track. Structure and offsets follow the
 * public community documentation (Wierzba/Bedesem, "Style Files -
 * Introduction and Details", explicitly released as uncopyrighted for
 * educational/implementation use) - see docs/STY_NATIVE_FORMAT.md.
 *
 * VERIFICATION STATUS: written and reviewed carefully, but never compiled
 * or run against a real file (no JVM/Android toolchain was available in
 * the environment that produced it).
 */
class StyParseException(message: String) : Exception(message)

object StyParser {

    fun parse(bytes: ByteArray): StyleDocument {
        val doc = StyleDocument()
        if (bytes.size < 22) throw StyParseException("File too small to be a style/MIDI file")
        if (!matches(bytes, 0, "MThd")) throw StyParseException("Missing MThd header - not a style/MIDI file")

        val headerLen = readU32BE(bytes, 4)
        if (headerLen < 6 || 8 + headerLen + 8 > bytes.size) throw StyParseException("Malformed MThd header")
        doc.meta.ppqn = readU16BE(bytes, 12).let { if (it <= 0 || it >= 0x8000) 96 else it }

        var pos = 8 + headerLen
        if (!matches(bytes, pos, "MTrk")) throw StyParseException("Missing MTrk track chunk")
        val trackLen = readU32BE(bytes, pos + 4)
        val trackStart = pos + 8
        val trackEnd = minOf(trackStart + trackLen, bytes.size)
        if (trackLen < 0) throw StyParseException("Malformed MTrk length")

        val allEvents = decodeTrack(bytes, trackStart, trackEnd)
        pos = trackStart + trackLen

        // Trailing Yamaha chunks: 4-char id + 4-byte BIG-endian length.
        var casm: ByteArray? = null
        while (pos >= 0 && pos + 8 <= bytes.size) {
            val id = String(bytes, pos, 4, Charsets.ISO_8859_1)
            val len = readU32BE(bytes, pos + 4)
            val dataStart = pos + 8
            val dataEnd = dataStart + len
            if (len < 0 || dataEnd > bytes.size) break
            if (id == "CASM") casm = bytes.copyOfRange(dataStart, dataEnd)
            // OTSc / FNRc / MHhd: One Touch Settings / Music Finder / unknown -
            // not needed for accompaniment playback; intentionally not parsed.
            pos = dataEnd
        }

        // --- Meta: tempo, time signature, copyright, markers ---------------
        val tempoEvents = mutableListOf<Pair<Long, Int>>()   // tick -> micros per quarter
        val markers = mutableListOf<Pair<Long, String>>()
        for (ev in allEvents) {
            if (!ev.isMeta) continue
            when (ev.metaType) {
                0x51 -> if (ev.data1 > 0) tempoEvents.add(ev.absoluteTicks to ev.data1)
                0x58 -> if (doc.meta.numerator == 4 && doc.meta.denominator == 4 && ev.data1 > 0) {
                    doc.meta.numerator = ev.data1
                    doc.meta.denominator = (1 shl ev.data2.coerceIn(0, 6))
                }
                0x02 -> ev.text?.let { if (doc.meta.copyright.isEmpty()) doc.meta.copyright = it }
                0x01, 0x03, 0x06 -> ev.text?.let { markers.add(ev.absoluteTicks to it) }
            }
        }
        val baseMicros = tempoEvents.firstOrNull()?.second ?: 500000
        doc.meta.tempoBpm = 60000000.0 / baseMicros

        val sffIdx = markers.indexOfFirst { it.second.startsWith("SFF") }
        if (sffIdx >= 0 && sffIdx + 1 < markers.size && SectionId.fromMarkerText(markers[sffIdx + 1].second) == null &&
            markers[sffIdx + 1].second != "SInt") {
            doc.meta.name = markers[sffIdx + 1].second.trim { it == '\u0000' || it.isWhitespace() }
        }

        // --- Section boundaries ---------------------------------------------------
        // Every documented marker ends the previous section, including ones we do not play
        // (Intro D / Ending D / Fill In AB), otherwise their notes would leak into it.
        val hits = markers.mapNotNull { (tick, text) ->
            val id = SectionId.fromMarkerText(text)
            if (id != null) Triple(tick, id as SectionId?, true)
            else if (SectionId.isIgnoredMarker(text)) Triple(tick, null, false) else null
        }.sortedBy { it.first }
        if (hits.none { it.third }) throw StyParseException("No recognised style-section markers (Main A, Intro A, ...) in the MIDI track")

        val trackEndTick = allEvents.maxOfOrNull { it.absoluteTicks } ?: 0L
        val firstSectionTick = hits.first().first
        for (ev in allEvents) {
            if (ev.absoluteTicks >= firstSectionTick) break
            if (ev.isProgramChange) doc.initialProgramByChannel[ev.channel] = ev.data1
            if (ev.isControlChange && ev.data1 == 0) doc.initialBankMsbByChannel[ev.channel] = ev.data2
            if (ev.isControlChange && ev.data1 == 7) doc.initialVolumeByChannel[ev.channel] = ev.data2
            if (ev.isControlChange && ev.data1 == 10) doc.initialPanByChannel[ev.channel] = ev.data2
        }

        val castMap: Map<SectionId, List<ChannelMapping>> =
            if (casm != null) try { CasmParser.parse(casm) } catch (e: Exception) { emptyMap() } else emptyMap()

        for ((i, hit) in hits.withIndex()) {
            val (start, id, supported) = hit
            if (!supported || id == null) continue
            val end = if (i + 1 < hits.size) hits[i + 1].first else trackEndTick
            val length = (end - start).coerceAtLeast(1)
            val section = StyleSection(id, start, length)

            // Half-bar-fill / multi-tempo trick: a tempo in effect at the section start that
            // differs from the base tempo scales playback of that section.
            val micros = tempoEvents.lastOrNull { it.first <= start }?.second ?: baseMicros
            section.tempoScale = baseMicros.toDouble() / micros.toDouble()

            val inRange = allEvents.filter { it.absoluteTicks in start until end && (it.status and 0xF0) in 0x80..0xE0 }
            for (ch in inRange.map { it.channel }.toSortedSet()) {
                val track = ChannelTrack(resolveMapping(castMap, id, ch))
                for (ev in inRange) if (ev.channel == ch) track.events.add(ev.copy(absoluteTicks = ev.absoluteTicks - start))
                track.events.sortBy { it.absoluteTicks }
                section.channels.add(track)
            }
            doc.sections[id] = section
        }
        return doc
    }

    /** Documented no-CASM convention: channels 9-16 map 1:1, authored in
     * CMaj7, with the "typical" NTR/NTT per part. */
    private fun resolveMapping(castMap: Map<SectionId, List<ChannelMapping>>, section: SectionId, ch: Int): ChannelMapping {
        castMap[section]?.firstOrNull { it.sourceChannel0to15 == ch }?.let { return it }
        val part = PartId.forDestChannel(ch + 1) ?: PartId.Chord1
        val (ntr, ntt) = when (part) {
            PartId.SubRhythm, PartId.Rhythm -> Ntr.RootFixed to Ntt.Bypass
            PartId.Bass -> Ntr.RootTrans to Ntt.Bass
            PartId.Chord1, PartId.Chord2, PartId.Pad -> Ntr.RootFixed to Ntt.Chord
            PartId.Phrase1, PartId.Phrase2 -> Ntr.RootTrans to Ntt.Melody
        }
        // High Key 11 (B) = roots always move upward 0..11 (no folding); drums auto-start, other parts wait for a chord.
        return ChannelMapping(ch, part, ntr, ntt, 0, ChordCatalog.TONES.getValue("Maj7"), 11, 0, 127, Rtr.PitchShift,
            0xFFF, null, part.isDrum)
    }

    // ----- Standard MIDI track decoding (public SMF spec) ------------------------
    internal fun decodeTrack(bytes: ByteArray, start: Int, end: Int): List<MidiEvent> {
        val events = mutableListOf<MidiEvent>()
        var pos = start
        var abs = 0L
        var running = 0
        while (pos < end) {
            val (delta, afterDelta) = readVarLen(bytes, pos, end)
            pos = afterDelta
            abs += delta
            if (pos >= end) break
            val sb = bytes[pos].toInt() and 0xFF

            if (sb == 0xFF) {
                pos++
                if (pos >= end) break
                val type = bytes[pos].toInt() and 0xFF; pos++
                val (len, afterLen) = readVarLen(bytes, pos, end)
                pos = afterLen
                val l = len.toInt()
                if (l < 0 || pos + l > end) break
                when (type) {
                    0x51 -> if (l >= 3) {
                        val micros = ((bytes[pos].toInt() and 0xFF) shl 16) or ((bytes[pos + 1].toInt() and 0xFF) shl 8) or (bytes[pos + 2].toInt() and 0xFF)
                        events.add(MidiEvent(abs, 0xFF, micros, 0, type))
                    }
                    0x58 -> if (l >= 2) events.add(MidiEvent(abs, 0xFF, bytes[pos].toInt() and 0xFF, bytes[pos + 1].toInt() and 0xFF, type))
                    0x01, 0x02, 0x03, 0x06 -> events.add(MidiEvent(abs, 0xFF, 0, 0, type, String(bytes, pos, l, Charsets.ISO_8859_1).trim { it == '\u0000' || it.isWhitespace() }))
                    else -> events.add(MidiEvent(abs, 0xFF, 0, 0, type))
                }
                pos += l
                if (type == 0x2F) break
                continue
            }
            if (sb == 0xF0 || sb == 0xF7) {
                pos++
                val (len, afterLen) = readVarLen(bytes, pos, end)
                pos = afterLen + len.toInt()
                continue
            }

            val status: Int
            if (sb and 0x80 != 0) { status = sb; pos++ } else status = running
            if (status == 0) break
            running = status
            val hi = status and 0xF0
            val two = !(hi == 0xC0 || hi == 0xD0)
            if (pos >= end) break
            val d1 = bytes[pos].toInt() and 0xFF; pos++
            var d2 = 0
            if (two) { if (pos >= end) break; d2 = bytes[pos].toInt() and 0xFF; pos++ }
            events.add(MidiEvent(abs, status, d1, d2))
        }
        return events
    }

    private fun readVarLen(bytes: ByteArray, start: Int, end: Int): Pair<Long, Int> {
        var v = 0L; var p = start
        for (i in 0 until 4) {
            if (p >= end) break
            val b = bytes[p].toInt() and 0xFF; p++
            v = (v shl 7) or (b and 0x7F).toLong()
            if (b and 0x80 == 0) break
        }
        return v to p
    }

    private fun matches(b: ByteArray, off: Int, s: String): Boolean {
        if (off < 0 || off + s.length > b.size) return false
        for (i in s.indices) if ((b[off + i].toInt() and 0xFF) != s[i].code) return false
        return true
    }
    private fun readU32BE(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)
    private fun readU16BE(b: ByteArray, o: Int): Int = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
}
