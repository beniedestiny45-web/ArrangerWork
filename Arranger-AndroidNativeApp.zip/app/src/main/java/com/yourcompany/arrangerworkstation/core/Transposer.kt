package com.yourcompany.arrangerworkstation.core

/** Chord tone sets (semitones above the root) keyed by the documented chord-type names. */
object ChordCatalog {
    val TONES: Map<String, Set<Int>> = mapOf(
        "Maj" to setOf(0, 4, 7), "Maj6" to setOf(0, 4, 7, 9), "Maj7" to setOf(0, 4, 7, 11),
        "Maj7#11" to setOf(0, 4, 6, 7, 11), "Maj(9)" to setOf(0, 2, 4, 7), "Maj7(9)" to setOf(0, 2, 4, 7, 11),
        "Maj6(9)" to setOf(0, 2, 4, 7, 9), "aug" to setOf(0, 4, 8),
        "min" to setOf(0, 3, 7), "min6" to setOf(0, 3, 7, 9), "min7" to setOf(0, 3, 7, 10),
        "min7b5" to setOf(0, 3, 6, 10), "min(9)" to setOf(0, 2, 3, 7), "min7(9)" to setOf(0, 2, 3, 7, 10),
        "min7(11)" to setOf(0, 3, 5, 7, 10), "minMaj7" to setOf(0, 3, 7, 11), "minMaj7(9)" to setOf(0, 2, 3, 7, 11),
        "dim" to setOf(0, 3, 6), "dim7" to setOf(0, 3, 6, 9),
        "7th" to setOf(0, 4, 7, 10), "7sus4" to setOf(0, 5, 7, 10), "7b5" to setOf(0, 4, 6, 10),
        "7(9)" to setOf(0, 2, 4, 7, 10), "7#11" to setOf(0, 4, 6, 7, 10), "7(13)" to setOf(0, 4, 7, 9, 10),
        "7(b9)" to setOf(0, 1, 4, 7, 10), "7(b13)" to setOf(0, 4, 7, 8, 10), "7(#9)" to setOf(0, 3, 4, 7, 10),
        "Maj7aug" to setOf(0, 4, 8, 11), "7aug" to setOf(0, 4, 8, 10),
        "1+8" to setOf(0), "1+5" to setOf(0, 7), "sus4" to setOf(0, 5, 7), "1+2+5" to setOf(0, 2, 7),
        "cancel" to setOf(0),
    )

    fun lookup(name: String): Set<Int> {
        TONES[name]?.let { return it }
        val lower = name.lowercase()
        for ((k, v) in TONES) if (k.lowercase() == lower) return v
        val aliases = mapOf("m" to "min", "maj" to "Maj", "7" to "7th", "m7" to "min7", "dom7" to "7th")
        aliases[lower]?.let { a -> TONES[a]?.let { return it } }
        return TONES.getValue("Maj")
    }
}

/**
 * Note transposition per the public style-file documentation:
 *  - NTT Bypass: untouched.
 *  - NTR Root Trans: the whole pattern moves UPWARD by 0..11 semitones from the source root to the
 *    target root; a target root above the High Key is played an octave lower (High Key F: roots
 *    C C# D F play up, F# plays 6 semitones DOWN). High Key is a real value (00 = C), not "off".
 *  - NTR Root Fixed + Melody/Chord: the "most important notes" rule - 3-note chords: all notes;
 *    4-note chords: all but the root; 5-note chords: all but root and fifth. Each important source
 *    tone maps to a DISTINCT important tone of the target chord, minimizing total movement so the
 *    part stays in its register (C3 E3 G3 -> C3 F3 A3 going C to F).
 *  - Melodic / Harmonic minor: only the 3rd (and 6th) move on a major<->minor change.
 */
object Transposer {

    fun nearestOffset(fromPc: Int, toPc: Int): Int {
        var d = ((toPc - fromPc) % 12 + 12) % 12
        if (d > 6) d -= 12
        return d
    }

    /** Root Trans motion: upward 0..11, folded one octave down above the High Key. */
    fun rootTransShift(m: ChannelMapping, targetRootPc: Int): Int {
        val rel = ((targetRootPc - m.sourceRootPitchClass) % 12 + 12) % 12
        return if (targetRootPc > m.highKeyPitchClass.coerceIn(0, 11)) rel - 12 else rel
    }

    private fun important(tones: Set<Int>): IntArray {
        val s = tones.sorted()
        val list = when {
            s.size <= 3 -> s
            s.size == 4 -> s.filter { it != 0 }
            else -> s.filter { it != 0 && it != 7 }
        }
        return list.toIntArray()
    }

    /**
     * Per-source-pitch-class semitone offsets for NTR Root Fixed:
     * table[(note - sourceRoot) mod 12] is added to the note. Built once per
     * (channel, chord) by the engine and cached, so no allocation per note.
     */
    fun buildFixedTable(m: ChannelMapping, targetRootPc: Int, targetTones: Set<Int>): IntArray {
        val srcRoot = m.sourceRootPitchClass
        val follow = nearestOffset(srcRoot, targetRootPc)       // default: follow the root motion
        val table = IntArray(12) { follow }
        val s = important(m.sourceChordTones)
        val d = important(if (targetTones.isEmpty()) setOf(0, 4, 7) else targetTones)
        if (s.isEmpty() || d.isEmpty()) return table
        val srcPc = IntArray(s.size) { (srcRoot + s[it]) % 12 }
        val dstPc = IntArray(d.size) { (targetRootPc + d[it]) % 12 }

        val cur = IntArray(s.size)
        val best = IntArray(s.size) { it.coerceAtMost(d.size - 1) }
        val bestCost = intArrayOf(Int.MAX_VALUE)

        fun search(i: Int, used: Int, cost: Int) {
            if (cost >= bestCost[0]) return
            if (i == s.size) { bestCost[0] = cost; for (k in cur.indices) best[k] = cur[k]; return }
            val allUsed = Integer.bitCount(used) >= d.size
            for (j in d.indices) {
                if (!allUsed && ((used shr j) and 1) == 1) continue
                cur[i] = j
                search(i + 1, used or (1 shl j), cost + kotlin.math.abs(nearestOffset(srcPc[i], dstPc[j])))
            }
        }
        search(0, 0, 0)
        for (i in s.indices) table[s[i] % 12] = nearestOffset(srcPc[i], dstPc[best[i]])
        if (m.sourceChordTones.size >= 5) {   // root and fifth always go to the target root and fifth
            table[0] = nearestOffset(srcRoot, targetRootPc)
            if (targetTones.contains(7)) table[7] = nearestOffset((srcRoot + 7) % 12, (targetRootPc + 7) % 12)
        }
        return table
    }

    fun transposeNote(
        note: Int,
        m: ChannelMapping,
        targetRootPc: Int,
        targetTones: Set<Int>,
        targetIsMinor: Boolean,
        sourceIsMinor: Boolean,
        fixedTable: IntArray? = null,
    ): Int? {
        if (m.ntt == Ntt.Bypass) return clamp(note, m)

        if (m.ntt == Ntt.MelodicMinor || m.ntt == Ntt.HarmonicMinor) {
            var r = note
            val pc = ((note - m.sourceRootPitchClass) % 12 + 12) % 12
            if (sourceIsMinor != targetIsMinor) {
                if (pc == 4 && targetIsMinor) r -= 1
                else if (pc == 3 && !targetIsMinor) r += 1
                else if (m.ntt == Ntt.HarmonicMinor) {
                    if (pc == 9 && targetIsMinor) r -= 1
                    else if (pc == 8 && !targetIsMinor) r += 1
                }
            }
            val shift = if (m.ntr == Ntr.RootTrans) rootTransShift(m, targetRootPc)
            else nearestOffset(m.sourceRootPitchClass, targetRootPc)
            return clamp(r + shift, m)
        }

        if (m.ntr == Ntr.RootTrans) return clamp(note + rootTransShift(m, targetRootPc), m)

        // Root Fixed (Guitar fret mapping is approximated as Root Fixed).
        val table = fixedTable ?: buildFixedTable(m, targetRootPc, targetTones)
        return clamp(note + table[((note - m.sourceRootPitchClass) % 12 + 12) % 12], m)
    }

    private fun clamp(note: Int, m: ChannelMapping): Int? {
        var n = note
        if (n < 0 || n > 127) return null
        val lo = m.noteLowLimit; val hi = m.noteHighLimit
        if (lo in 0..127 && hi in 0..127 && hi - lo >= 11) {
            while (n < lo) n += 12
            while (n > hi) n -= 12
            if (n < lo || n > hi) return null
        }
        return n
    }
}
