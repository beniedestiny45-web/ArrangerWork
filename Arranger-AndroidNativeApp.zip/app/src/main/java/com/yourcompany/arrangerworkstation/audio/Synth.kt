package com.yourcompany.arrangerworkstation.audio

import com.yourcompany.arrangerworkstation.core.Bus
import com.yourcompany.arrangerworkstation.core.EngineEvent
import com.yourcompany.arrangerworkstation.core.EventBuffer
import com.yourcompany.arrangerworkstation.core.EventType
import com.yourcompany.arrangerworkstation.core.MixerState
import com.yourcompany.arrangerworkstation.core.PartId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Software synthesizer that turns engine events into real 16-bit PCM.
 * It is a synthesizer (oscillators + filters + envelopes + a synthesized
 * drum kit), NOT a sample/soundfont player: GM program numbers select one
 * of 16 instrument-family recipes, so the accompaniment follows the
 * style's real notes, timing and chords with a generic (not
 * instrument-accurate) timbre. Event timing is sample-accurate inside
 * each block. Everything is pre-allocated; render() never allocates.
 */
class Synth(private val sr: Int, private val mixer: MixerState, maxFrames: Int = 2048) {

    companion object {
        private const val MAX_VOICES = 80
        private const val TWO_PI = 2.0 * PI
        private const val W_SINE = 0; private const val W_TRI = 1; private const val W_SAW = 2; private const val W_SQR = 3
    }

    private class Timbre(
        val w1: Int, val w2: Int, val detuneCents: Float, val level2: Float,
        val attack: Float, val decay: Float, val sustain: Float, val release: Float,
        val cutoff: Float, val gain: Float,
    )

    // One recipe per GM instrument family (program / 8).
    private val families = arrayOf(
        Timbre(W_TRI, W_SAW, 4f, 0.25f, 0.004f, 0.9f, 0.25f, 0.35f, 4500f, 0.55f),   // piano
        Timbre(W_SINE, W_TRI, 0f, 0.3f, 0.002f, 0.7f, 0.0f, 0.5f, 9000f, 0.5f),      // chromatic perc
        Timbre(W_SINE, W_SQR, 1200f, 0.35f, 0.01f, 0.05f, 1.0f, 0.08f, 6000f, 0.45f), // organ
        Timbre(W_SAW, W_TRI, 6f, 0.3f, 0.002f, 0.6f, 0.2f, 0.3f, 3200f, 0.5f),       // guitar
        Timbre(W_SAW, W_SINE, -1200f, 0.6f, 0.005f, 0.25f, 0.7f, 0.12f, 900f, 0.8f), // bass
        Timbre(W_SAW, W_SAW, 9f, 0.8f, 0.25f, 0.3f, 0.9f, 0.5f, 3500f, 0.4f),        // strings
        Timbre(W_SAW, W_TRI, 7f, 0.6f, 0.3f, 0.3f, 0.9f, 0.6f, 3000f, 0.4f),         // ensemble/choir
        Timbre(W_SAW, W_SQR, 5f, 0.3f, 0.06f, 0.2f, 0.75f, 0.15f, 3500f, 0.45f),     // brass
        Timbre(W_SQR, W_TRI, 3f, 0.4f, 0.04f, 0.2f, 0.8f, 0.15f, 2500f, 0.4f),       // reed
        Timbre(W_SINE, W_TRI, 2f, 0.2f, 0.06f, 0.1f, 0.9f, 0.2f, 5000f, 0.5f),       // pipe
        Timbre(W_SAW, W_SQR, 8f, 0.5f, 0.01f, 0.2f, 0.8f, 0.15f, 6000f, 0.4f),       // synth lead
        Timbre(W_SAW, W_SAW, 11f, 0.8f, 0.5f, 0.4f, 0.85f, 0.9f, 2800f, 0.35f),      // synth pad
        Timbre(W_TRI, W_SAW, 15f, 0.3f, 0.1f, 0.5f, 0.6f, 0.5f, 3000f, 0.4f),        // synth fx
        Timbre(W_TRI, W_SAW, 3f, 0.2f, 0.003f, 0.5f, 0.2f, 0.3f, 3500f, 0.5f),       // ethnic
        Timbre(W_SINE, W_TRI, 0f, 0.3f, 0.002f, 0.3f, 0.0f, 0.3f, 8000f, 0.5f),      // percussive
        Timbre(W_SINE, W_TRI, 0f, 0.2f, 0.01f, 0.5f, 0.5f, 0.4f, 4000f, 0.4f),       // sfx
    )

    private class DrumPatch(
        val f0: Float, val f1: Float, val pitchTau: Float,
        val toneDecay: Float, val toneLevel: Float,
        val noiseLevel: Float, val noiseDecay: Float, val hiCoef: Float, val loCoef: Float,
        val metalLevel: Float, val metalDecay: Float, val gain: Float,
    ) { val duration: Float = max(max(toneDecay, noiseDecay), metalDecay) * 1.25f + 0.02f }

    private val METAL_FREQS = floatArrayOf(263f, 400f, 421f, 474f, 587f, 845f)

    private fun drumPatch(note: Int): DrumPatch = when (note) {
        35, 36 -> DrumPatch(155f, 46f, 0.035f, 0.38f, 1.0f, 0.15f, 0.02f, 0.5f, 0f, 0f, 0.01f, 1.0f)
        37 -> DrumPatch(820f, 700f, 0.01f, 0.03f, 0.6f, 0.4f, 0.03f, 0.6f, 0.1f, 0f, 0.01f, 0.8f)
        38, 40 -> DrumPatch(230f, 175f, 0.02f, 0.12f, 0.55f, 0.9f, 0.22f, 0.7f, 0.08f, 0f, 0.01f, 0.9f)
        39 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 1.0f, 0.18f, 0.6f, 0.15f, 0f, 0.01f, 0.8f)
        41 -> tom(90f); 43 -> tom(110f); 45 -> tom(135f); 47 -> tom(160f); 48 -> tom(190f); 50 -> tom(220f)
        42 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.5f, 0.05f, 0.9f, 0.55f, 0.6f, 0.05f, 0.5f)
        44 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.5f, 0.06f, 0.9f, 0.55f, 0.6f, 0.06f, 0.5f)
        46 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.5f, 0.35f, 0.9f, 0.55f, 0.6f, 0.35f, 0.5f)
        49, 57 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.8f, 1.4f, 0.9f, 0.5f, 0.5f, 1.4f, 0.55f)
        51, 59, 53 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.35f, 0.9f, 0.9f, 0.55f, 0.55f, 0.9f, 0.4f)
        52 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.7f, 0.9f, 0.9f, 0.45f, 0.5f, 0.9f, 0.5f)
        54 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.8f, 0.15f, 0.9f, 0.5f, 0.3f, 0.15f, 0.5f)
        56 -> DrumPatch(587f, 587f, 0.01f, 0.2f, 0.5f, 0.05f, 0.02f, 0.6f, 0f, 0.3f, 0.2f, 0.7f)
        69, 70 -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.7f, 0.08f, 0.85f, 0.5f, 0f, 0.01f, 0.5f)
        75 -> DrumPatch(2500f, 2500f, 0.01f, 0.04f, 0.8f, 0f, 0.01f, 0.5f, 0f, 0f, 0.01f, 0.7f)
        76 -> DrumPatch(1000f, 1000f, 0.01f, 0.06f, 0.9f, 0.05f, 0.01f, 0.6f, 0f, 0f, 0.01f, 0.9f)
        77 -> DrumPatch(700f, 700f, 0.01f, 0.06f, 0.9f, 0.05f, 0.01f, 0.6f, 0f, 0f, 0.01f, 0.9f)
        80, 81 -> DrumPatch(3000f, 3000f, 0.01f, 0.8f, 0.5f, 0f, 0.01f, 0.5f, 0f, 0f, 0.01f, 0.5f)
        else -> DrumPatch(0f, 0f, 0.01f, 0.01f, 0f, 0.6f, 0.05f, 0.7f, 0.2f, 0f, 0.01f, 0.5f)
    }
    private fun tom(f: Float) = DrumPatch(f * 1.6f, f, 0.05f, 0.3f, 0.9f, 0.08f, 0.04f, 0.5f, 0f, 0f, 0.01f, 0.9f)
    private val drumPatches: Array<DrumPatch> = Array(128) { drumPatch(it) }

    private class Voice {
        @JvmField var active = false
        @JvmField var releasing = false
        @JvmField var key = 0
        @JvmField var bus = 0
        @JvmField var ch = -1           // style MIDI channel 0..15 (live CC7/10/11 mixing); -1 for pads/click
        @JvmField var drum = false
        @JvmField var note = 0
        @JvmField var age = 0L
        @JvmField var vel = 0f
        @JvmField var pan = 0.5f
        // melodic
        @JvmField var timbre: Timbre? = null
        @JvmField var freq = 440.0
        @JvmField var target = 440.0
        @JvmField var ph1 = 0.0
        @JvmField var ph2 = 0.0
        @JvmField var env = 0f
        @JvmField var stage = 0
        @JvmField var lp = 0f
        // drum
        @JvmField var patch: DrumPatch? = null
        @JvmField var samples = 0
        @JvmField var tonePh = 0.0
        @JvmField var lpHi = 0f
        @JvmField var lpLo = 0f
        @JvmField val metalPh = DoubleArray(6)
        @JvmField var rng = 22222
    }

    // Live per-channel controllers, updated by CHAN events (CC7 volume, CC10 pan, CC11 expression).
    private val chanVol = FloatArray(16) { 100f / 127f }
    private val chanPan = FloatArray(16) { 0.5f }
    private val chanExpr = FloatArray(16) { 1f }

    private val voices = Array(MAX_VOICES) { Voice() }
    private var ageCounter = 0L

    private val mixL = FloatArray(maxFrames)
    private val mixR = FloatArray(maxFrames)
    private val rev = FloatArray(maxFrames)
    private val reverb = Reverb(sr)
    @Volatile var reverbLevel = 0.14f

    /** Per-bus output peak (0..1+), decaying; read by the UI for meters. */
    val busLevels = FloatArray(10)
    private val busPeak = FloatArray(10)

    // ---------------------------------------------------------------- render
    fun render(out: ShortArray, frames: Int, events: EventBuffer) {
        val n = min(frames, mixL.size)
        java.util.Arrays.fill(mixL, 0, n, 0f)
        java.util.Arrays.fill(mixR, 0, n, 0f)
        java.util.Arrays.fill(rev, 0, n, 0f)
        java.util.Arrays.fill(busPeak, 0f)

        sortByTime(events)
        var pos = 0
        for (i in 0 until events.count) {
            val e = events.items[i]
            val idx = (e.timeSeconds * sr).toInt().coerceIn(0, n - 1)
            if (idx > pos) { renderVoices(pos, idx); pos = idx }
            handleEvent(e)
        }
        if (pos < n) renderVoices(pos, n)

        val master = mixer.masterVolume
        val wet = reverbLevel
        for (i in 0 until n) {
            reverb.process(rev[i])
            val l = tanh((mixL[i] + reverb.outL * wet) * master)
            val r = tanh((mixR[i] + reverb.outR * wet) * master)
            out[2 * i] = (l * 32000f).toInt().toShort()
            out[2 * i + 1] = (r * 32000f).toInt().toShort()
        }
        for (b in 0 until 10) busLevels[b] = max(busPeak[b], busLevels[b] * 0.9f)
    }

    private fun sortByTime(buf: EventBuffer) {
        val a = buf.items
        for (i in 1 until buf.count) {
            val x = a[i]; var j = i - 1
            while (j >= 0 && a[j].timeSeconds > x.timeSeconds) { a[j + 1] = a[j]; j-- }
            a[j + 1] = x
        }
    }

    // ---------------------------------------------------------------- events
    private fun handleEvent(e: EngineEvent) {
        when (e.type) {
            EventType.ON -> noteOn(e)
            EventType.CLICK -> noteOn(e)
            EventType.CHAN -> {
                val c = e.note and 15
                when (e.key) {
                    7 -> chanVol[c] = e.velocity / 127f
                    10 -> chanPan[c] = e.velocity / 127f
                    11 -> chanExpr[c] = e.velocity / 127f
                }
            }
            EventType.OFF -> for (v in voices) if (v.active && !v.releasing && !v.drum && v.key == e.key) release(v)
            EventType.RETUNE -> for (v in voices) if (v.active && !v.releasing && !v.drum && v.key == e.key) v.target = hz(e.note)
            EventType.ALL_OFF -> for (v in voices) if (v.active && !v.drum) release(v)
        }
    }

    private fun hz(note: Int): Double = 440.0 * 2.0.pow((note - 69) / 12.0)

    private fun release(v: Voice) { v.releasing = true; v.stage = 3 }

    private fun allocate(): Voice {
        var free: Voice? = null
        for (v in voices) if (!v.active) { free = v; break }
        if (free != null) return free
        var best: Voice? = null
        var bestScore = Float.MAX_VALUE
        for (v in voices) {
            val score = if (v.releasing) v.env else 10f + (ageCounter - v.age).let { -it.toFloat() }
            if (score < bestScore) { bestScore = score; best = v }
        }
        return best!!
    }

    private fun noteOn(e: EngineEvent) {
        val v = allocate()
        v.active = true; v.releasing = false; v.key = e.key; v.bus = e.bus; v.note = e.note
        v.age = ++ageCounter; v.pan = e.pan
        v.ch = if (e.bus < 8 && e.key < 4096) (e.key shr 7) and 15 else -1
        if (e.isDrum || e.type == EventType.CLICK) {
            // Hi-hat choke: a closed/pedal hat cuts any ringing open hat on the same bus.
            if (e.note == 42 || e.note == 44) for (o in voices) if (o.active && o.drum && o.note == 46 && o.bus == e.bus) o.active = false
            var vel = e.velocity / 127f
            if ((e.note == 35 || e.note == 36) && e.bus != Bus.CLICK) vel *= mixer.kickVolume
            v.drum = true; v.patch = drumPatches[e.note and 127]; v.vel = vel
            v.samples = 0; v.tonePh = 0.0; v.lpHi = 0f; v.lpLo = 0f; v.rng = 1234567 + e.note * 7919 + (ageCounter.toInt() * 31)
            for (i in 0 until 6) v.metalPh[i] = 0.0
        } else {
            v.drum = false
            v.timbre = families[(e.program / 8).coerceIn(0, 15)]
            v.vel = (e.velocity / 127f).let { it * it * 0.4f + it * 0.6f }
            v.freq = hz(e.note); v.target = v.freq
            v.ph1 = 0.0; v.ph2 = 0.0; v.env = 0f; v.stage = 0; v.lp = 0f
        }
    }

    // ---------------------------------------------------------------- DSP
    private fun busGain(bus: Int): Float {
        if (bus == Bus.CLICK) return 0.6f
        if (bus == Bus.PAD) return mixer.padVolume
        val parts = mixer.parts
        var anySolo = false
        for (p in parts) if (p.solo) { anySolo = true; break }
        val pm = parts[bus]
        val audible = if (anySolo) pm.solo else !pm.mute
        if (!audible) return 0f
        var g = pm.volume * mixer.styleVolume
        if (bus == PartId.Bass.ordinal) g *= mixer.bassVolume
        return g
    }

    private fun renderVoices(from: Int, to: Int) {
        for (v in voices) {
            if (!v.active) continue
            var g = busGain(v.bus)
            var pan = v.pan
            if (v.ch >= 0) { g *= chanVol[v.ch] * chanExpr[v.ch]; pan = chanPan[v.ch] }
            if (v.bus < 8) pan = (pan + mixer.parts[v.bus].pan - 0.5f).coerceIn(0f, 1f)
            val gl = cos(pan * (PI / 2)).toFloat() * 1.2f * g
            val gr = sin(pan * (PI / 2)).toFloat() * 1.2f * g
            val send = if (v.bus == Bus.CLICK) 0f else 0.6f
            if (v.drum) renderDrum(v, from, to, gl, gr, send) else renderMelodic(v, from, to, gl, gr, send)
        }
    }

    private fun polyBlep(t: Double, dt: Double): Double {
        if (t < dt) { val x = t / dt; return x + x - x * x - 1.0 }
        if (t > 1.0 - dt) { val x = (t - 1.0) / dt; return x * x + x + x + 1.0 }
        return 0.0
    }

    private fun osc(wave: Int, ph: Double, inc: Double): Double = when (wave) {
        W_SINE -> sin(TWO_PI * ph)
        W_TRI -> 4.0 * abs(ph - 0.5) - 1.0
        W_SAW -> 2.0 * ph - 1.0 - polyBlep(ph, inc)
        else -> (if (ph < 0.5) 1.0 else -1.0) + polyBlep(ph, inc) - polyBlep((ph + 0.5) % 1.0, inc)
    }

    private fun renderMelodic(v: Voice, from: Int, to: Int, gl: Float, gr: Float, send: Float) {
        val tm = v.timbre ?: return
        val attackInc = 1f / (tm.attack * sr).coerceAtLeast(1f)
        val decayCoef = exp(-4.6f / (tm.decay * sr).coerceAtLeast(1f))
        val releaseCoef = exp(-4.6f / (tm.release * sr).coerceAtLeast(1f))
        val detuneRatio = 2.0.pow(tm.detuneCents / 1200.0)
        val keyTrack = (v.freq / 261.6).pow(0.4).toFloat()
        var peak = busPeak[v.bus]
        for (i in from until to) {
            when (v.stage) {
                0 -> { v.env += attackInc; if (v.env >= 1f) { v.env = 1f; v.stage = 1 } }
                1 -> { v.env = tm.sustain + (v.env - tm.sustain) * decayCoef; if (v.env - tm.sustain < 0.002f) { v.env = tm.sustain; v.stage = 2 } }
                3 -> { v.env *= releaseCoef; if (v.env < 0.0004f) { v.active = false; break } }
            }
            v.freq += (v.target - v.freq) * 0.004   // glide for pitch-shift chord changes
            val inc1 = v.freq / sr
            val inc2 = inc1 * detuneRatio
            v.ph1 += inc1; if (v.ph1 >= 1.0) v.ph1 -= 1.0
            v.ph2 += inc2; if (v.ph2 >= 1.0) v.ph2 -= 1.0
            val raw = (osc(tm.w1, v.ph1, inc1) + osc(tm.w2, v.ph2, inc2) * tm.level2) / (1f + tm.level2)
            val fc = tm.cutoff * (0.5f + v.vel * 0.8f) * (0.55f + 0.45f * v.env) * keyTrack
            val a = 1f - exp(-2f * PI.toFloat() * min(fc, sr * 0.45f) / sr)
            v.lp += a * (raw.toFloat() - v.lp)
            val s = v.lp * v.env * tm.gain * v.vel
            mixL[i] += s * gl; mixR[i] += s * gr; rev[i] += s * send * (gl + gr) * 0.5f
            val m = abs(s) * (gl + gr) * 0.5f
            if (m > peak) peak = m
        }
        busPeak[v.bus] = peak
    }

    private fun renderDrum(v: Voice, from: Int, to: Int, gl: Float, gr: Float, send: Float) {
        val p = v.patch ?: return
        val maxSamples = (p.duration * sr).toInt()
        val kHi = if (p.hiCoef > 0f) p.hiCoef else 0.5f
        val kLo = p.loCoef
        var peak = busPeak[v.bus]
        for (i in from until to) {
            val t = v.samples / sr.toFloat()
            if (v.samples >= maxSamples) { v.active = false; break }
            var s = 0f
            if (p.toneLevel > 0f) {
                val f = p.f1 + (p.f0 - p.f1) * exp(-t / p.pitchTau)
                v.tonePh += f / sr; if (v.tonePh >= 1.0) v.tonePh -= 1.0
                s += sin(TWO_PI * v.tonePh).toFloat() * p.toneLevel * exp(-4.6f * t / p.toneDecay)
            }
            if (p.noiseLevel > 0f) {
                v.rng = v.rng xor (v.rng shl 13); v.rng = v.rng xor (v.rng ushr 17); v.rng = v.rng xor (v.rng shl 5)
                val n = (v.rng.toFloat() / Int.MAX_VALUE.toFloat())
                v.lpHi += kHi * (n - v.lpHi)
                val band = if (kLo > 0f) { v.lpLo += kLo * (v.lpHi - v.lpLo); v.lpHi - v.lpLo } else v.lpHi
                s += band * p.noiseLevel * 2f * exp(-4.6f * t / p.noiseDecay)
            }
            if (p.metalLevel > 0f) {
                var m = 0f
                for (k in 0 until 6) {
                    v.metalPh[k] += METAL_FREQS[k] * (if (k % 2 == 0) 1.0 else 1.5) / sr
                    if (v.metalPh[k] >= 1.0) v.metalPh[k] -= 1.0
                    m += if (v.metalPh[k] < 0.5) 1f else -1f
                }
                s += (m / 6f) * p.metalLevel * 0.6f * exp(-4.6f * t / p.metalDecay)
            }
            s *= p.gain * v.vel
            v.samples++
            mixL[i] += s * gl; mixR[i] += s * gr; rev[i] += s * send * (gl + gr) * 0.5f
            val m = abs(s) * (gl + gr) * 0.5f
            if (m > peak) peak = m
        }
        busPeak[v.bus] = peak
    }
}

/** Small Schroeder-style reverb (4 combs + 2 all-passes), mono in / stereo out. */
class Reverb(sr: Int) {
    var outL = 0f; var outR = 0f
    private val scale = sr / 44100f
    private fun len(n: Int) = (n * scale).toInt().coerceAtLeast(8)
    private val combL = arrayOf(FloatArray(len(1116)), FloatArray(len(1188)), FloatArray(len(1277)), FloatArray(len(1356)))
    private val combR = arrayOf(FloatArray(len(1139)), FloatArray(len(1211)), FloatArray(len(1300)), FloatArray(len(1379)))
    private val idxL = IntArray(4); private val idxR = IntArray(4)
    private val apL = arrayOf(FloatArray(len(556)), FloatArray(len(441)))
    private val apR = arrayOf(FloatArray(len(579)), FloatArray(len(464)))
    private val apIdxL = IntArray(2); private val apIdxR = IntArray(2)
    private val feedback = 0.82f
    private val damp = 0.25f
    private val lpL = FloatArray(4); private val lpR = FloatArray(4)

    fun process(input: Float) {
        val x = input * 0.12f
        var l = 0f; var r = 0f
        for (i in 0 until 4) {
            val bl = combL[i]; val yl = bl[idxL[i]]
            lpL[i] = yl * (1f - damp) + lpL[i] * damp
            bl[idxL[i]] = x + lpL[i] * feedback
            idxL[i] = (idxL[i] + 1) % bl.size; l += yl
            val br = combR[i]; val yr = br[idxR[i]]
            lpR[i] = yr * (1f - damp) + lpR[i] * damp
            br[idxR[i]] = x + lpR[i] * feedback
            idxR[i] = (idxR[i] + 1) % br.size; r += yr
        }
        for (i in 0 until 2) {
            val bl = apL[i]; val dl = bl[apIdxL[i]]
            val ol = -l + dl; bl[apIdxL[i]] = l + dl * 0.5f; apIdxL[i] = (apIdxL[i] + 1) % bl.size; l = ol
            val br = apR[i]; val dr = br[apIdxR[i]]
            val or2 = -r + dr; br[apIdxR[i]] = r + dr * 0.5f; apIdxR[i] = (apIdxR[i] + 1) % br.size; r = or2
        }
        outL = l; outR = r
    }
}
