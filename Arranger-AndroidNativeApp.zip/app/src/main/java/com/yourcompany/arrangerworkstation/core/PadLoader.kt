package com.yourcompany.arrangerworkstation.core

/**
 * Loads a Standard MIDI File (Type 0 or 1, any number of tracks) as a
 * Multi Pad clip. Pads are plain .mid/.midi files chosen by the user; the
 * clip plays once from the start each time its pad is triggered, at the
 * current arranger tempo, optionally re-voiced to the played chord.
 */
object PadLoader {

    fun load(bytes: ByteArray, name: String, chordTracked: Boolean): PadClip {
        if (bytes.size < 14 || String(bytes, 0, 4, Charsets.ISO_8859_1) != "MThd") {
            throw StyParseException("Not a MIDI file (missing MThd)")
        }
        val headerLen = u32(bytes, 4)
        val numTracks = u16(bytes, 10)
        val ppqn = u16(bytes, 12).let { if (it <= 0 || it >= 0x8000) 96 else it }

        val events = mutableListOf<MidiEvent>()
        var pos = 8 + headerLen
        var tracksRead = 0
        while (pos + 8 <= bytes.size && tracksRead < numTracks.coerceAtLeast(1)) {
            val id = String(bytes, pos, 4, Charsets.ISO_8859_1)
            val len = u32(bytes, pos + 4)
            val start = pos + 8
            if (len < 0) break
            val end = minOf(start + len, bytes.size)
            if (id == "MTrk") {
                for (e in StyParser.decodeTrack(bytes, start, end)) {
                    if ((e.status and 0xF0) in 0x80..0xE0) events.add(e)
                }
                tracksRead++
            }
            pos = start + len
        }
        if (events.none { it.isNoteOn }) throw StyParseException("MIDI file contains no notes")
        events.sortBy { it.absoluteTicks }

        val programs = HashMap<Int, Int>()
        for (e in events) if (e.isProgramChange && !programs.containsKey(e.channel)) programs[e.channel] = e.data1
        val length = events.maxOf { it.absoluteTicks } + ppqn / 4
        return PadClip(name, events, ppqn, length, chordTracked, programs)
    }

    private fun u32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)
    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
}
