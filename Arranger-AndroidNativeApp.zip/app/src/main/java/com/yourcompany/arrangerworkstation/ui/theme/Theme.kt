package com.yourcompany.arrangerworkstation.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Palette {
    val Bg = Color(0xFF070A11)
    val BgTop = Color(0xFF0E1426)
    val Card = Color(0xFF111826)
    val Card2 = Color(0xFF18213A)
    val Stroke = Color(0xFF26314B)
    val Text = Color(0xFFE8ECF6)
    val Dim = Color(0xFF8993AB)
    val Violet = Color(0xFF8B5CF6)
    val Cyan = Color(0xFF22D3EE)
    val Green = Color(0xFF34D399)
    val Amber = Color(0xFFFBBF24)
    val Rose = Color(0xFFFB7185)
    val Blue = Color(0xFF60A5FA)
    val partColors = listOf(Amber, Rose, Green, Violet, Blue, Cyan, Color(0xFFF472B6), Color(0xFFA3E635))
}

private val scheme = darkColorScheme(
    primary = Palette.Violet, secondary = Palette.Cyan, background = Palette.Bg, surface = Palette.Card,
    onPrimary = Color.White, onBackground = Palette.Text, onSurface = Palette.Text,
)

private val type = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp, letterSpacing = (-0.5).sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, letterSpacing = 0.4.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.8.sp),
)

@Composable
fun ArrangerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}

/** Rounded card with a soft border and a section title. */
@Composable
fun Panel(title: String, modifier: Modifier = Modifier, trailing: @Composable (() -> Unit)? = null, content: @Composable () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(24.dp), ambientColor = Color.Black, spotColor = Color.Black)
            .background(Brush.verticalGradient(listOf(Palette.Card2, Palette.Card)), RoundedCornerShape(24.dp))
            .border(BorderStroke(1.dp, Palette.Stroke), RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.fillMaxWidth()) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelSmall, color = Palette.Dim, modifier = Modifier.align(Alignment.CenterStart))
            if (trailing != null) Box(Modifier.align(Alignment.CenterEnd)) { trailing() }
        }
        content()
    }
}

/**
 * Glowing pill/tile button: animated press-scale, animated colour and glow
 * when `active`, dimmed when disabled. The glow is a coloured shadow.
 */
@Composable
fun GlowButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    pending: Boolean = false,
    enabled: Boolean = true,
    height: Int = 52,
    onClick: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.55f, stiffness = 600f), label = "press")
    val glow by animateDpAsState(if (active) 18.dp else if (pending) 8.dp else 0.dp, tween(260), label = "glow")
    val fill by animateColorAsState(
        if (active) color else if (pending) color.copy(alpha = 0.45f) else Palette.Card2, tween(220), label = "fill",
    )
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(height.dp)
            .scale(scale)
            .alpha(if (enabled) 1f else 0.32f)
            .shadow(glow, shape, ambientColor = color, spotColor = color)
            .background(Brush.verticalGradient(listOf(fill, fill.copy(alpha = 0.78f))), shape)
            .border(BorderStroke(1.dp, if (active || pending) color else Palette.Stroke), shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (active) Color(0xFF0A0F1C) else Palette.Text,
            fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 0.5.sp,
        )
    }
}

/** Horizontal level meter with an animated fill. */
@Composable
fun LevelMeter(level: Float, color: Color, modifier: Modifier = Modifier) {
    val l by animateFloatAsState(level.coerceIn(0f, 1f), tween(60), label = "meter")
    Box(modifier.height(8.dp).background(Palette.Bg, RoundedCornerShape(4.dp))) {
        Box(
            Modifier
                .fillMaxWidth(l)
                .height(8.dp)
                .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.55f), color)), RoundedCornerShape(4.dp)),
        )
    }
}
