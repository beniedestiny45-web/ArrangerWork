package com.yourcompany.arrangerworkstation

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.yourcompany.arrangerworkstation.ui.ArrangerViewModel
import com.yourcompany.arrangerworkstation.ui.MainScreen
import com.yourcompany.arrangerworkstation.ui.theme.ArrangerTheme

/**
 * Single-activity host. Audio is a native AudioTrack pipeline (no WebView),
 * started in onStart and released in onStop. The screen stays on while the
 * app is in the foreground so a playing style is never interrupted by the
 * display timing out.
 */
class MainActivity : ComponentActivity() {
    private val vm: ArrangerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC
        setContent { ArrangerTheme { MainScreen(vm) } }
    }

    override fun onStart() { super.onStart(); vm.onStart() }
    override fun onStop() { vm.onStop(); super.onStop() }
}
