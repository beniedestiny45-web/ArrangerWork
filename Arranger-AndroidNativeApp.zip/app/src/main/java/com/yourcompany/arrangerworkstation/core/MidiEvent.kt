package com.yourcompany.arrangerworkstation.core

/**
 * A MIDI event at an absolute tick position - the same event model used
 * by the C++ (Source/Core/MidiEvent.h) and JS (WebApp/js/engine.js)
 * ports of this engine. No Android dependency.
 */
data class MidiEvent(
    val absoluteTicks: Long,
    val status: Int,            // 0x80-0xEF channel events, 0xFF meta
    val data1: Int = 0,
    val data2: Int = 0,
    val metaType: Int = -1,     // valid only when status == 0xFF
    val text: String? = null,   // decoded text for meta text/marker/name events
) {
    val isNoteOn: Boolean get() = (status and 0xF0) == 0x90 && data2 > 0
    val isNoteOff: Boolean get() = (status and 0xF0) == 0x80 || ((status and 0xF0) == 0x90 && data2 == 0)
    val isControlChange: Boolean get() = (status and 0xF0) == 0xB0
    val isProgramChange: Boolean get() = (status and 0xF0) == 0xC0
    val isMeta: Boolean get() = status == 0xFF
    val channel: Int get() = status and 0x0F
}
