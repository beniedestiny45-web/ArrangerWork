package com.yourcompany.arrangerworkstation.core

import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.floor
import kotlin.math.min

/** Mixer state shared (lock-free, volatile scalars) between the UI thread,
 * the engine and the synthesizer. */
class PartMix {
    @Volatile var volume: Float = 0.85f
    @Volatile var pan: Float = 0.5f
    @Volatile var mute: Boolean = false
    @Volatile var solo: Boolean = false
}

class MixerState {
    val parts: Array<PartMix> = Array(PartId.values().size) { PartMix() }
    @Volatile var styleVolume: Float = 0.9f
    @Volatile var padVolume: Float = 0.9f
    @Volatile var kickVolume: Float = 1.0f
    @Volatile var bassVolume: Float = 1.0f
    @Volatile var masterVolume: Float = 0.9f
    fun part(p: PartId) = parts[p.ordinal]
}

object EventType { const val ON = 0; const val OFF = 1; const val RETUNE = 2; const val ALL_OFF = 3; const val CLICK = 4; const val CHAN = 5 }
object Bus { const val PAD = 8; const val CLICK = 9 }

/** Reusable event record - the audio thread never allocates per event. */
class EngineEvent {
    @JvmField var timeSeconds = 0.0
    @JvmField var type = 0
    @JvmField var key = 0
    @JvmField var note = 0
    @JvmField var velocity = 0
    @JvmField var bus = 0          // 0..7 = PartId ordinal, 8 = multi pad, 9 = metronome
    @JvmField var program = 0
    @JvmField var isDrum = false
    @JvmField var pan = 0.5f
}

class EventBuffer(capacity: Int = 2048) {
    val items: Array<EngineEvent> = Array(capacity) { EngineEvent() }
    @JvmField var count = 0
    fun clear() { count = 0 }
    fun add(): EngineEvent? = if (count < items.size) items[count++] else null
}

class PadClip(
    val name: String,
    val events: List<MidiEvent>,   // in the clip's own ticks
    val ppqn: Int,                 // clip's own resolution; played at the current tempo
    val lengthTicks: Long,
    val chordTracked: Boolean,
    val programByChannel: Map<Int, Int>,
)

enum class TransportState { Stopped, Playing, SyncArmedStart, SyncStopMode }

class StyleEngine(private val mixer: MixerState) {

    // ---- UI-visible snapshot (volatile, written by the audio thread) -------
    @Volatile var uiState: TransportState = TransportState.Stopped; private set
    @Volatile var uiSection: SectionId = SectionId.MainA; private set
    @Volatile var uiQueued: SectionId? = null; private set
    @Volatile var uiChordName: String = "C Maj"; private set
    @Volatile var uiTempo: Double = 120.0; private set
    @Volatile var uiBar: Int = 1; private set
    @Volatile var uiBeat: Int = 1; private set
    @Volatile var uiStyleName: String = "No style loaded"; private set
    @Volatile var uiTempoLocked: Boolean = false; private set
    @Volatile var uiTranspose: Int = 0; private set
    @Volatile var uiMetronome: Boolean = false; private set
    @Volatile var uiAutoFill: Boolean = true; private set
    @Volatile var uiRequireChord: Boolean = false; private set
    @Volatile var uiAvailableSections: Set<SectionId> = emptySet(); private set
    @Volatile var uiPadActive: BooleanArray = BooleanArray(4); private set
    @Volatile var uiPadNames: Array<String> = arrayOf("Pad 1", "Pad 2", "Pad 3", "Pad 4"); private set

    // ---- Audio-thread-only state ---------------------------------------------
    private val commands = ConcurrentLinkedQueue<(EventBuffer) -> Unit>()
    private var doc: StyleDocument? = null
    private var pendingStyle: StyleDocument? = null
    private var state = TransportState.Stopped
    private var current = SectionId.MainA
    private var lastMain = SectionId.MainA
    private val queue = ArrayDeque<SectionId>()
    private var tempo = 120.0
    private var tempoLocked = false
    private var transpose = 0
    private var metronome = false
    private var autoFill = true
    private val recognizer = ChordRecognizerState()
    private val defaultChord = RecognizedChord(true, 0, 0, "Maj", false)   // C major assumed until the player chooses one
    private var chord = defaultChord
    private var chordUserSet = false
    private var requireChord = false          // true = wait for a first chord like a hardware arranger (only autostart parts play)
    private val fixedTables = HashMap<ChannelMapping, IntArray>()
    private var currentTick = 0
    private var lastEmittedTick = -1
    private var acc = 0.0
    private var cursors = IntArray(16)
    private var metroNext = 0

    private val chanVol = IntArray(16) { 100 }
    private val chanPan = IntArray(16) { 64 }
    private val chanProgram = IntArray(16)
    private val chanExpr = IntArray(16) { 127 }
    private val chanBank = IntArray(16) { -1 }

    // Active-note tables keyed by srcChannel*128+srcNote (style) so a
    // note-off always releases exactly the pitch its note-on played.
    private val activeOut = IntArray(2048) { -1 }
    private val activeVel = IntArray(2048)
    private val activeMap = arrayOfNulls<ChannelMapping>(2048)

    private class PadState { var active = false; var tick = 0; var lastEmitted = -1; var cursor = 0 }
    private val padClips = arrayOfNulls<PadClip>(4)
    private val padState = Array(4) { PadState() }
    private val padActiveOut = IntArray(4 * 128) { -1 }
    private val padDefaultMapping = ChannelMapping(
        0, PartId.Phrase1, Ntr.RootFixed, Ntt.Chord, 0, ChordCatalog.TONES["Maj7"]!!, 0, 0, 127, Rtr.PitchShift,
    )

    // =================== Public, thread-safe control API ====================
    fun post(cmd: (EventBuffer) -> Unit) { commands.add(cmd) }

    fun loadStyle(newDoc: StyleDocument) = post { out ->
        if (state == TransportState.Playing || state == TransportState.SyncStopMode) {
            pendingStyle = newDoc      // swapped at the next bar line: playback never stops
        } else applyStyle(newDoc, out)
    }
    fun start() = post { out -> if (doc != null) { state = TransportState.Playing; resetPlayhead(out); publish() } }
    fun stop() = post { out ->
        state = TransportState.Stopped; releaseAll(out, 0.0); resetPlayhead(out); queue.clear()
        pendingStyle?.let { ps -> pendingStyle = null; val tp = tempo; applyStyle(ps, out); if (tempoLocked) tempo = tp }
        publish()
    }
    fun syncStart() = post { out -> if (doc != null) { state = TransportState.SyncArmedStart; resetPlayhead(out); publish() } }
    fun syncStop() = post { _ -> state = TransportState.SyncStopMode; publish() }
    fun requestSection(id: SectionId) = post { out -> handleRequest(id, out) }
    fun chordNoteOn(note: Int) = post { out -> chordInput(recognizer.noteOn(note), out); armStartIfNeeded(out) }
    fun chordNoteOff(note: Int) = post { out -> val c = recognizer.noteOff(note); if (c.valid) chordInput(c, out) }
    /** On-screen chord entry: sets the chord directly (no held-note set). */
    fun setChord(rootPc: Int, typeName: String) = post { out ->
        val minor = typeName.startsWith("min") && !typeName.startsWith("minMaj")
        chordInput(RecognizedChord(true, rootPc, rootPc, typeName, minor || typeName == "min"), out)
        armStartIfNeeded(out)
    }
    fun setTempo(bpm: Double) = post { _ -> tempo = bpm.coerceIn(30.0, 300.0); publish() }
    fun nudgeTempo(delta: Double) = post { _ -> tempo = (tempo + delta).coerceIn(30.0, 300.0); publish() }
    fun setTempoLock(lock: Boolean) = post { _ -> tempoLocked = lock; publish() }
    fun setTranspose(semis: Int) = post { _ -> transpose = semis.coerceIn(-12, 12); publish() }
    fun setMetronome(on: Boolean) = post { _ -> metronome = on; publish() }
    fun setAutoFill(on: Boolean) = post { _ -> autoFill = on; publish() }
    fun setRequireChord(on: Boolean) = post { out ->
        requireChord = on
        if (!chordUserSet) { chord = if (on) RecognizedChord() else defaultChord; fixedTables.clear(); uiChordName = if (on) "—" else "C Maj" }
        retargetActiveNotes(out); publish()
    }
    fun loadPad(index: Int, clip: PadClip) = post { _ -> if (index in 0..3) { padClips[index] = clip; publishPads() } }
    fun triggerPad(index: Int) = post { _ ->
        if (index in 0..3 && padClips[index] != null) { padState[index].apply { active = true; tick = 0; lastEmitted = -1; cursor = 0 }; publishPads() }
    }
    fun stopPad(index: Int) = post { out -> if (index in 0..3) { padState[index].active = false; releasePad(index, out, 0.0); publishPads() } }

    // =================== Command / state helpers (audio thread) =================
    private fun drainCommands(out: EventBuffer) {
        while (true) { val c = commands.poll() ?: break; c(out) }
    }

    private fun armStartIfNeeded(out: EventBuffer) {
        if (state == TransportState.SyncArmedStart) { state = TransportState.Playing; resetPlayhead(out); publish() }
    }

    private fun applyStyle(newDoc: StyleDocument, out: EventBuffer) {
        releaseAll(out, 0.0)
        doc = newDoc
        if (!tempoLocked) tempo = newDoc.meta.tempoBpm
        fixedTables.clear()
        for (ch in 0 until 16) {
            chanVol[ch] = newDoc.initialVolumeByChannel[ch] ?: 100
            chanPan[ch] = newDoc.initialPanByChannel[ch] ?: 64
            chanProgram[ch] = newDoc.initialProgramByChannel[ch] ?: 0
            chanBank[ch] = newDoc.initialBankMsbByChannel[ch] ?: -1
            chanExpr[ch] = 127
            emitChan(out, ch, 7, chanVol[ch]); emitChan(out, ch, 10, chanPan[ch]); emitChan(out, ch, 11, 127)
        }
        // Keep the user's place where possible (same section in the new style).
        val keep = if (newDoc.sections.containsKey(current)) current
        else listOf(SectionId.MainA, SectionId.MainB, SectionId.MainC, SectionId.MainD).firstOrNull { newDoc.sections.containsKey(it) }
            ?: newDoc.sections.keys.first()
        current = keep
        if (current.isMain) lastMain = current
        currentTick = 0; lastEmittedTick = -1; cursors.fill(0); metroNext = 0; acc = 0.0
        queue.clear()
        uiStyleName = newDoc.meta.name
        publish()
    }

    private fun resetPlayhead(out: EventBuffer) {
        currentTick = 0; lastEmittedTick = -1; cursors.fill(0); metroNext = 0; acc = 0.0
    }

    private fun switchTo(id: SectionId, out: EventBuffer, atTime: Double) {
        val d = doc ?: return
        if (!d.sections.containsKey(id)) return
        releaseAll(out, atTime)
        current = id
        if (id.isMain) lastMain = id
        currentTick = 0; lastEmittedTick = -1; cursors.fill(0); metroNext = 0
        publish()
    }

    private fun handleRequest(id: SectionId, out: EventBuffer) {
        val d = doc ?: return
        if (!d.sections.containsKey(id)) return
        if (state == TransportState.Stopped || state == TransportState.SyncArmedStart) {
            current = id; if (id.isMain) lastMain = id
            currentTick = 0; lastEmittedTick = -1; cursors.fill(0)
            if (state == TransportState.Stopped && id.isIntro) state = TransportState.Playing
            publish(); return
        }
        // Choosing a Main during an Intro selects where the Intro will land; it never cuts the Intro short.
        if (current.isIntro && id.isMain) { lastMain = id; publish(); return }
        queue.clear()
        if (id.isMain && autoFill && current.isMain && id != current) {
            val fill = fillFor(id)
            if (fill != null && d.sections.containsKey(fill)) queue.addLast(fill)
        }
        queue.addLast(id)
        publish()
    }

    private fun fillFor(main: SectionId): SectionId? = when (main) {
        SectionId.MainA -> SectionId.FillA; SectionId.MainB -> SectionId.FillB
        SectionId.MainC -> SectionId.FillC; SectionId.MainD -> SectionId.FillD
        else -> null
    }
    private fun mainAfterFill(fill: SectionId): SectionId = when (fill) {
        SectionId.FillA -> SectionId.MainA; SectionId.FillB -> SectionId.MainB
        SectionId.FillC -> SectionId.MainC; SectionId.FillD -> SectionId.MainD
        else -> lastMain
    }

    private fun chordInput(c: RecognizedChord, out: EventBuffer) {
        if (!c.valid) return
        val changed = !chord.valid || chord.rootPitchClass != c.rootPitchClass || chord.typeName != c.typeName
        chord = c; chordUserSet = true
        if (changed) fixedTables.clear()
        uiChordName = "${NOTE_NAMES[c.rootPitchClass]} ${c.typeName}"
        if (changed) retargetActiveNotes(out)
    }

    private fun sourceIsMinor(m: ChannelMapping): Boolean = m.sourceChordTones.contains(3) && !m.sourceChordTones.contains(4)

    /** SubRhythm may carry a melodic voice; it is only a drum part if its bank is a drum kit (or unknown). */
    private fun isDrum(m: ChannelMapping): Boolean = when (m.destPart) {
        PartId.Rhythm -> true
        PartId.SubRhythm -> chanBank[m.sourceChannel0to15].let { it < 0 || it == 120 || it == 126 || it == 127 }
        else -> false
    }

    /** Note Mute / Chord Mute / autostart: does this channel sound for the current chord? */
    private fun channelAllowed(m: ChannelMapping): Boolean {
        if (!chord.valid) return m.autoStart
        if ((m.noteMuteMask shr chord.rootPitchClass) and 1 == 0) return false
        val plays = m.chordPlays
        return plays == null || plays.contains(chord.typeName)
    }

    private fun transposeFor(m: ChannelMapping, note: Int): Int? {
        if (isDrum(m)) return note
        val root = if (chord.valid) chord.rootPitchClass else m.sourceRootPitchClass
        val tones = if (chord.valid) ChordCatalog.lookup(chord.typeName) else m.sourceChordTones
        val minor = if (chord.valid) chord.isMinor else sourceIsMinor(m)
        val table = if (m.ntr != Ntr.RootTrans && m.ntt != Ntt.Bypass && m.ntt != Ntt.MelodicMinor && m.ntt != Ntt.HarmonicMinor)
            fixedTables.getOrPut(m) { Transposer.buildFixedTable(m, root, tones) } else null
        val t = Transposer.transposeNote(note, m, root, tones, minor, sourceIsMinor(m), table) ?: return null
        val r = t + transpose
        return if (r in 0..127) r else null
    }

    private fun emitChanAt(out: EventBuffer, t: Double, channel: Int, cc: Int, value: Int) {
        val e = out.add() ?: return
        e.timeSeconds = t; e.type = EventType.CHAN; e.key = cc; e.note = channel; e.velocity = value
        e.bus = 0; e.program = 0; e.isDrum = false; e.pan = 0.5f
    }

    private fun emitChan(out: EventBuffer, channel: Int, cc: Int, value: Int) {
        val e = out.add() ?: return
        e.timeSeconds = 0.0; e.type = EventType.CHAN; e.key = cc; e.note = channel; e.velocity = value
        e.bus = 0; e.program = 0; e.isDrum = false; e.pan = 0.5f
    }

    private fun retargetActiveNotes(out: EventBuffer) {
        for (key in 0 until 2048) {
            val old = activeOut[key]
            if (old < 0) continue
            val m = activeMap[key] ?: continue
            if (!channelAllowed(m)) {
                emit(out, 0.0, EventType.OFF, key, old, 0, m.destPart.ordinal, 0, false, 0.5f); activeOut[key] = -1; continue
            }
            if (m.ntt == Ntt.Bypass) continue
            val srcNote = key and 127
            val nw = transposeFor(m, srcNote)
            if (nw == null) {
                emit(out, 0.0, EventType.OFF, key, old, 0, m.destPart.ordinal, 0, false, 0.5f); activeOut[key] = -1; continue
            }
            if (nw == old) continue
            when (m.rtr) {
                Rtr.Stop -> { emit(out, 0.0, EventType.OFF, key, old, 0, m.destPart.ordinal, 0, false, 0.5f); activeOut[key] = -1 }
                Rtr.Retrigger, Rtr.RetriggerToRoot -> {
                    emit(out, 0.0, EventType.OFF, key, old, 0, m.destPart.ordinal, 0, false, 0.5f)
                    emit(out, 0.0, EventType.ON, key, nw, activeVel[key], m.destPart.ordinal, chanProgram[key shr 7], false, 0.5f)
                    activeOut[key] = nw
                }
                else -> { // PitchShift / PitchShiftToRoot / NoteGenerator: glide without re-attack
                    emit(out, 0.0, EventType.RETUNE, key, nw, 0, m.destPart.ordinal, 0, false, 0.5f)
                    activeOut[key] = nw
                }
            }
        }
    }

    private fun releaseAll(out: EventBuffer, atTime: Double) {
        for (key in 0 until 2048) {
            val old = activeOut[key]
            if (old >= 0) {
                val m = activeMap[key]
                emit(out, atTime, EventType.OFF, key, old, 0, m?.destPart?.ordinal ?: 0, 0, false, 0.5f)
                activeOut[key] = -1
            }
        }
    }

    private fun releasePad(index: Int, out: EventBuffer, atTime: Double) {
        for (n in 0 until 128) {
            val o = padActiveOut[index * 128 + n]
            if (o >= 0) { emit(out, atTime, EventType.OFF, 4096 + index * 128 + n, o, 0, Bus.PAD, 0, false, 0.5f); padActiveOut[index * 128 + n] = -1 }
        }
    }

    private fun emit(out: EventBuffer, t: Double, type: Int, key: Int, note: Int, vel: Int, bus: Int, program: Int, drum: Boolean, pan: Float) {
        val e = out.add() ?: return
        e.timeSeconds = t; e.type = type; e.key = key; e.note = note; e.velocity = vel
        e.bus = bus; e.program = program; e.isDrum = drum; e.pan = pan
    }

    // =================== Real-time advance ===================================
    /** Called once per audio block by the audio thread. */
    fun advance(dt: Double, out: EventBuffer) {
        drainCommands(out)
        advancePads(dt, out)

        val d = doc ?: return
        val ticking = state == TransportState.Playing || (state == TransportState.SyncStopMode && recognizer.held.isNotEmpty())
        if (!ticking) return

        val ppqn = d.meta.ppqn
        var remainingSeconds = dt
        var timeCursor = 0.0
        var guard = 0
        while (remainingSeconds > 1e-9 && guard++ < 10000) {
            val sec = d.sections[current] ?: break
            // Tempo may differ per section (half-bar-fill trick); handled per chunk.
            val tps = tempo * sec.tempoScale * ppqn / 60.0
            val secPerTick = 1.0 / tps
            val avail = acc + remainingSeconds * tps        // ticks available incl. carried fraction
            val whole = floor(avail).toInt()
            if (whole <= 0) { acc = avail; break }

            val len = sec.lengthTicks.toInt().coerceAtLeast(1)
            val bar = barTicks(d, sec)
            var limit = len
            var barBoundary = false
            if (queue.isNotEmpty() || pendingStyle != null) {
                val nb = (currentTick / bar + 1) * bar
                if (nb < limit) { limit = nb; barBoundary = true }
            }
            val step = min(whole, (limit - currentTick).coerceAtLeast(1))

            // Event at tick e occurs (e - playhead - acc) ticks after this chunk starts.
            emitRange(sec, lastEmittedTick, currentTick + step, currentTick,
                timeCursor - acc * secPerTick, secPerTick, out)
            lastEmittedTick = currentTick + step
            currentTick += step

            val leftover = avail - step
            if (leftover < 1.0) { acc = leftover; remainingSeconds = 0.0 }
            else { acc = 0.0; remainingSeconds = leftover / tps }
            timeCursor = dt - remainingSeconds

            if (currentTick >= limit) {
                if (barBoundary && currentTick < len) atBarBoundary(out, timeCursor)
                else atSectionEnd(sec, out, timeCursor)
                if (state == TransportState.Stopped) break
            }
        }
        val curSec = d.sections[current]
        if (curSec != null) {
            val bt = barTicks(d, curSec)
            uiBar = currentTick / bt + 1
            uiBeat = ((currentTick % bt) * numeratorOf(d) / bt) + 1
        }
    }

    private fun numeratorOf(d: StyleDocument) = d.meta.numerator.coerceAtLeast(1)

    private fun barTicks(d: StyleDocument, sec: StyleSection): Int =
        (d.meta.ppqn * 4 * numeratorOf(d) / d.meta.denominator.coerceAtLeast(1)).coerceAtLeast(1)

    private fun atBarBoundary(out: EventBuffer, t: Double) {
        pendingStyle?.let { ps ->
            pendingStyle = null
            val wasTempo = tempo
            applyStyle(ps, out)
            if (tempoLocked) tempo = wasTempo
            // keep playing from the top of the corresponding section
            return
        }
        val next = queue.removeFirstOrNull() ?: return
        switchTo(next, out, t)
    }

    private fun atSectionEnd(sec: StyleSection, out: EventBuffer, t: Double) {
        val d = doc ?: return
        pendingStyle?.let { ps -> pendingStyle = null; val tp = tempo; applyStyle(ps, out); if (tempoLocked) tempo = tp; return }
        val queued = queue.removeFirstOrNull()
        if (queued != null) { switchTo(queued, out, t); return }
        if (sec.loops) { releaseAll(out, t); currentTick = 0; lastEmittedTick = -1; cursors.fill(0); metroNext = 0; return }
        when {
            sec.id.isEnding -> { releaseAll(out, t); state = TransportState.Stopped; resetPlayhead(out) }
            sec.id == SectionId.Intro1 || sec.id == SectionId.Intro2 || sec.id == SectionId.Intro3 -> {
                val target = when {
                    d.sections.containsKey(lastMain) -> lastMain
                    d.sections.containsKey(SectionId.MainA) -> SectionId.MainA
                    else -> d.sections.keys.firstOrNull { it.isMain } ?: lastMain
                }
                switchTo(target, out, t)
            }
            else -> {
                val target = mainAfterFill(sec.id)
                switchTo(if (d.sections.containsKey(target)) target else lastMain, out, t)
            }
        }
    }

    private fun emitRange(
        sec: StyleSection, fromExclusive: Int, toInclusive: Int, playhead: Int,
        timeBase: Double, secPerTick: Double, out: EventBuffer,
    ) {
        for ((ci, track) in sec.channels.withIndex()) {
            if (ci >= cursors.size) break
            val evs = track.events
            var c = cursors[ci]
            val m = track.mapping
            val ch = m.sourceChannel0to15
            while (c < evs.size && evs[c].absoluteTicks <= toInclusive) {
                val ev = evs[c]
                if (ev.absoluteTicks > fromExclusive) {
                    val t = timeBase + (ev.absoluteTicks.toInt() - playhead) * secPerTick
                    val key = ch * 128 + (ev.data1 and 127)
                    when {
                        ev.isNoteOn -> {
                            val outNote = if (channelAllowed(m)) transposeFor(m, ev.data1) else null
                            if (outNote != null) {
                                if (activeOut[key] >= 0) emit(out, t, EventType.OFF, key, activeOut[key], 0, m.destPart.ordinal, 0, false, 0.5f)
                                val vel = ev.data2.coerceIn(1, 127)      // raw velocity; channel volume/expression/pan are mixer-side (CHAN events)
                                activeOut[key] = outNote; activeVel[key] = vel; activeMap[key] = m
                                emit(out, t, EventType.ON, key, outNote, vel, m.destPart.ordinal, chanProgram[ch], isDrum(m), 0.5f)
                            }
                        }
                        ev.isNoteOff -> {
                            val o = activeOut[key]
                            if (o >= 0) { emit(out, t, EventType.OFF, key, o, 0, m.destPart.ordinal, 0, false, 0.5f); activeOut[key] = -1 }
                        }
                        ev.isProgramChange -> chanProgram[ch] = ev.data1
                        ev.isControlChange -> when (ev.data1) {
                            0 -> chanBank[ch] = ev.data2
                            7 -> { chanVol[ch] = ev.data2; emitChanAt(out, t, ch, 7, ev.data2) }
                            10 -> { chanPan[ch] = ev.data2; emitChanAt(out, t, ch, 10, ev.data2) }
                            11 -> { chanExpr[ch] = ev.data2; emitChanAt(out, t, ch, 11, ev.data2) }
                        }
                    }
                }
                c++
            }
            cursors[ci] = c
        }
        if (metronome) {
            val d = doc!!
            val ticksPerBeat = (d.meta.ppqn * 4 / d.meta.denominator.coerceAtLeast(1)).coerceAtLeast(1)
            while (metroNext <= toInclusive) {
                if (metroNext > fromExclusive) {
                    val downbeat = (metroNext / ticksPerBeat) % numeratorOf(d) == 0
                    emit(out, timeBase + (metroNext - playhead) * secPerTick, EventType.CLICK, 0, if (downbeat) 76 else 77,
                        if (downbeat) 120 else 90, Bus.CLICK, 0, true, 0.5f)
                }
                metroNext += ticksPerBeat
            }
        }
    }

    private fun advancePads(dt: Double, out: EventBuffer) {
        for (i in 0 until 4) {
            val st = padState[i]; if (!st.active) continue
            val clip = padClips[i] ?: continue
            val tps = tempo * clip.ppqn / 60.0
            val secPerTick = 1.0 / tps
            val whole = floor(dt * tps).toInt()
            if (whole <= 0) continue
            val to = st.tick + whole
            while (st.cursor < clip.events.size && clip.events[st.cursor].absoluteTicks <= to) {
                val ev = clip.events[st.cursor]
                if (ev.absoluteTicks > st.lastEmitted) {
                    val t = ((ev.absoluteTicks.toInt() - st.tick) * secPerTick).coerceAtLeast(0.0)
                    val drum = ev.channel == 9
                    val key = 4096 + i * 128 + (ev.data1 and 127)
                    if (ev.isNoteOn) {
                        val outNote = if (clip.chordTracked && !drum) transposeFor(padDefaultMapping, ev.data1) else ev.data1
                        if (outNote != null) {
                            padActiveOut[i * 128 + (ev.data1 and 127)] = outNote
                            emit(out, t, EventType.ON, key, outNote, ev.data2.coerceAtLeast(1), Bus.PAD, clip.programByChannel[ev.channel] ?: 0, drum, 0.5f)
                        }
                    } else if (ev.isNoteOff) {
                        val o = padActiveOut[i * 128 + (ev.data1 and 127)]
                        if (o >= 0) { emit(out, t, EventType.OFF, key, o, 0, Bus.PAD, 0, drum, 0.5f); padActiveOut[i * 128 + (ev.data1 and 127)] = -1 }
                    }
                }
                st.cursor++
            }
            st.lastEmitted = to; st.tick = to
            if (st.tick > clip.lengthTicks || st.cursor >= clip.events.size) {
                st.active = false; releasePad(i, out, whole * secPerTick); publishPads()
            }
        }
    }

    // =================== UI snapshot publishing ==================================
    private fun publish() {
        uiState = state; uiSection = current; uiQueued = queue.lastOrNull(); uiTempo = tempo
        uiTempoLocked = tempoLocked; uiTranspose = transpose; uiMetronome = metronome; uiAutoFill = autoFill; uiRequireChord = requireChord
        uiAvailableSections = doc?.sections?.keys?.toSet() ?: emptySet()
        if (doc != null) uiStyleName = doc!!.meta.name
    }
    private fun publishPads() {
        uiPadActive = BooleanArray(4) { padState[it].active }
        uiPadNames = Array(4) { padClips[it]?.name ?: "Pad ${it + 1}" }
    }

    companion object {
        val NOTE_NAMES = arrayOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B")
    }
}
