package com.yourcompany.arrangerworkstation.core

data class RecognizedChord(
    val valid: Boolean = false,
    val rootPitchClass: Int = 0,
    val bassPitchClass: Int = 0,
    val typeName: String = "Maj",
    val isMinor: Boolean = false,
)

enum class ChordInputMode { Fingered, SingleFinger }

/**
 * Template-matching chord recognizer: same algorithm (interval templates,
 * exact>subset scoring, bass-as-root bonus, priority tie-break) as the
 * tested C++ and JS ports. Template names match ChordCatalog keys.
 */
object ChordRecognizer {
    private class Template(val name: String, val intervals: List<Int>, val priority: Int)

    private val templates = listOf(
        Template("Maj7", listOf(0, 4, 7, 11), 0), Template("7th", listOf(0, 4, 7, 10), 0),
        Template("min7", listOf(0, 3, 7, 10), 0), Template("minMaj7", listOf(0, 3, 7, 11), 0),
        Template("min7b5", listOf(0, 3, 6, 10), 0), Template("dim7", listOf(0, 3, 6, 9), 0),
        Template("Maj6", listOf(0, 4, 7, 9), 1), Template("min6", listOf(0, 3, 7, 9), 1),
        Template("Maj(9)", listOf(0, 2, 4, 7), 1), Template("7sus4", listOf(0, 5, 7, 10), 1),
        Template("7b5", listOf(0, 4, 6, 10), 1), Template("7aug", listOf(0, 4, 8, 10), 1),
        Template("1+2+5", listOf(0, 2, 7), 2), Template("sus4", listOf(0, 5, 7), 2),
        Template("aug", listOf(0, 4, 8), 2), Template("dim", listOf(0, 3, 6), 2),
        Template("min", listOf(0, 3, 7), 3), Template("Maj", listOf(0, 4, 7), 3),
        Template("1+5", listOf(0, 7), 4),
    )

    private fun isMinorName(n: String) = n == "min" || n == "min7" || n == "min6" || n == "minMaj7" || n == "min7b5"

    private fun matchFingered(held: List<Int>): RecognizedChord {
        if (held.size < 2) return RecognizedChord()
        val pcSet = held.map { ((it % 12) + 12) % 12 }.toSet()
        val bassPc = ((held.min() % 12) + 12) % 12
        var bestScore = -1; var bestPriority = 1000; var bestRoot = 0; var bestName = ""
        for (root in pcSet) {
            for (t in templates) {
                val want = t.intervals.map { (root + it) % 12 }.toSet()
                var score = when {
                    want == pcSet -> 1000
                    pcSet.containsAll(want) -> want.size * 10
                    else -> -1
                }
                if (score < 0) continue
                if (root == bassPc) score += 1
                if (score > bestScore || (score == bestScore && t.priority < bestPriority)) {
                    bestScore = score; bestPriority = t.priority; bestRoot = root; bestName = t.name
                }
            }
        }
        if (bestScore < 0) return RecognizedChord()
        return RecognizedChord(true, bestRoot, bassPc, bestName, isMinorName(bestName))
    }

    private fun matchSingleFinger(held: List<Int>): RecognizedChord {
        if (held.isEmpty()) return RecognizedChord()
        val sorted = held.sorted()
        val rootPc = ((sorted[0] % 12) + 12) % 12
        var type = "Maj"
        for (i in 1 until sorted.size) {
            when (((sorted[i] - sorted[0]) % 12 + 12) % 12) { 3 -> type = "min"; 10 -> type = "7th"; 11 -> type = "Maj7" }
        }
        return RecognizedChord(true, rootPc, rootPc, type, isMinorName(type))
    }

    fun analyze(held: List<Int>, mode: ChordInputMode): RecognizedChord {
        if (held.isEmpty()) return RecognizedChord()
        return if (mode == ChordInputMode.SingleFinger && held.size <= 2) matchSingleFinger(held) else matchFingered(held)
    }
}

/** Held-note tracking wrapper (audio-thread use only). */
class ChordRecognizerState(var mode: ChordInputMode = ChordInputMode.Fingered) {
    val held: MutableSet<Int> = mutableSetOf()
    fun noteOn(note: Int): RecognizedChord { held.add(note); return ChordRecognizer.analyze(held.toList(), mode) }
    fun noteOff(note: Int): RecognizedChord {
        held.remove(note)
        return if (held.isEmpty()) RecognizedChord() else ChordRecognizer.analyze(held.toList(), mode)
    }
}
