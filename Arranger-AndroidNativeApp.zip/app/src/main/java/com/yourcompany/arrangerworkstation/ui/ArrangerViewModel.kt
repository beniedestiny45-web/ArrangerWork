package com.yourcompany.arrangerworkstation.ui

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yourcompany.arrangerworkstation.audio.AudioOutput
import com.yourcompany.arrangerworkstation.audio.MidiInputController
import com.yourcompany.arrangerworkstation.core.MixerState
import com.yourcompany.arrangerworkstation.core.PadLoader
import com.yourcompany.arrangerworkstation.core.PartId
import com.yourcompany.arrangerworkstation.core.SectionId
import com.yourcompany.arrangerworkstation.core.StyParser
import com.yourcompany.arrangerworkstation.core.StyleEngine
import com.yourcompany.arrangerworkstation.core.TransportState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Everything the screen shows that comes from the engine (value-equal, so
 * StateFlow only re-emits when something actually changed). */
data class UiSnapshot(
    val styleName: String = "No style loaded",
    val section: SectionId = SectionId.MainA,
    val queued: SectionId? = null,
    val transport: TransportState = TransportState.Stopped,
    val tempo: Double = 120.0,
    val tempoLocked: Boolean = false,
    val chord: String = "—",
    val bar: Int = 1,
    val beat: Int = 1,
    val available: Set<SectionId> = emptySet(),
    val padActive: List<Boolean> = List(4) { false },
    val padNames: List<String> = listOf("Pad 1", "Pad 2", "Pad 3", "Pad 4"),
    val metronome: Boolean = false,
    val autoFill: Boolean = true,
    val transpose: Int = 0,
    val midiDevices: List<String> = emptyList(),
    val requireChord: Boolean = false,
)

class ArrangerViewModel(app: Application) : AndroidViewModel(app) {
    val mixer = MixerState()
    val engine = StyleEngine(mixer)
    val audio = AudioOutput(app, engine, mixer)
    private val midi = MidiInputController(app, engine)

    private val _ui = MutableStateFlow(UiSnapshot())
    val ui: StateFlow<UiSnapshot> = _ui
    private val _levels = MutableStateFlow(List(10) { 0f })
    val levels: StateFlow<List<Float>> = _levels

    var message by mutableStateOf<String?>(null)
    var styleFile by mutableStateOf("—")
    var audioRunning by mutableStateOf(false)
    var padFiles by mutableStateOf(listOf("—", "—", "—", "—"))
    var padChordTracked by mutableStateOf(listOf(true, true, false, false))
    private val padBytes = arrayOfNulls<ByteArray>(4)
    private val padNames = arrayOfNulls<String>(4)
    private val tapTimes = ArrayDeque<Long>()

    init {
        viewModelScope.launch {
            while (true) {
                val e = engine
                _ui.value = UiSnapshot(
                    e.uiStyleName, e.uiSection, e.uiQueued, e.uiState, e.uiTempo, e.uiTempoLocked, e.uiChordName,
                    e.uiBar, e.uiBeat, e.uiAvailableSections, e.uiPadActive.toList(), e.uiPadNames.toList(),
                    e.uiMetronome, e.uiAutoFill, e.uiTranspose, midi.deviceNames, e.uiRequireChord,
                )
                val l = audio.synth.busLevels
                _levels.value = List(10) { (kotlin.math.min(l[it], 1f) * 32f).toInt() / 32f }
                audioRunning = audio.started
                delay(33)
            }
        }
        loadBundledDemo()
    }

    // ------------------------------------------------------------ lifecycle
    fun onStart() { audio.start(); midi.start() }
    fun onStop() { midi.stop(); audio.stop() }
    override fun onCleared() { midi.stop(); audio.stop() }

    // ------------------------------------------------------------ file import
    private fun displayName(uri: Uri): String =
        getApplication<Application>().contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: (uri.lastPathSegment ?: "style")

    private fun readBytes(uri: Uri): ByteArray =
        getApplication<Application>().contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("Could not open the selected file")

    fun importStyle(uri: Uri) {
        viewModelScope.launch {
            try {
                val name = displayName(uri)
                val doc = withContext(Dispatchers.Default) { StyParser.parse(readBytes(uri)) }
                engine.loadStyle(doc)
                styleFile = name
                message = "Loaded “${doc.meta.name}” — ${doc.sections.size} sections, ${doc.meta.tempoBpm.toInt()} BPM"
            } catch (e: Exception) {
                message = "Could not load style: ${e.message}"
            }
        }
    }

    private fun loadBundledDemo() {
        viewModelScope.launch {
            try {
                val assets = getApplication<Application>().assets
                val doc = withContext(Dispatchers.Default) { assets.open("demo/DemoPop110.sty").use { StyParser.parse(it.readBytes()) } }
                engine.loadStyle(doc)
                styleFile = "DemoPop110.sty (bundled)"
                val names = listOf("BrassHit", "ArpRun", "Crash", "Riser")
                names.forEachIndexed { i, n ->
                    val bytes = withContext(Dispatchers.Default) { assets.open("demo/pads/$n.mid").use { it.readBytes() } }
                    setPad(i, bytes, n, padChordTracked[i], "$n.mid (bundled)")
                }
            } catch (e: Exception) {
                message = "Bundled demo failed to load: ${e.message}"
            }
        }
    }

    fun importPad(index: Int, uri: Uri) {
        viewModelScope.launch {
            try {
                val name = displayName(uri)
                val bytes = withContext(Dispatchers.Default) { readBytes(uri) }
                setPad(index, bytes, name.substringBeforeLast('.'), padChordTracked[index], name)
                message = "Pad ${index + 1}: $name"
            } catch (e: Exception) {
                message = "Could not load pad: ${e.message}"
            }
        }
    }

    private fun setPad(index: Int, bytes: ByteArray, name: String, tracked: Boolean, file: String) {
        val clip = PadLoader.load(bytes, name, tracked)
        padBytes[index] = bytes; padNames[index] = name
        engine.loadPad(index, clip)
        padFiles = padFiles.toMutableList().also { it[index] = file }
    }

    fun togglePadChordTracking(index: Int) {
        val v = !padChordTracked[index]
        padChordTracked = padChordTracked.toMutableList().also { it[index] = v }
        val b = padBytes[index] ?: return
        try { engine.loadPad(index, PadLoader.load(b, padNames[index] ?: "Pad", v)) } catch (e: Exception) {}
    }

    // ------------------------------------------------------------ transport / controls
    fun playStop() { if (ui.value.transport == TransportState.Stopped || ui.value.transport == TransportState.SyncArmedStart) engine.start() else engine.stop() }
    fun syncStart() = engine.syncStart()
    fun section(id: SectionId) = engine.requestSection(id)
    fun nudgeTempo(d: Double) = engine.nudgeTempo(d)
    fun toggleTempoLock() = engine.setTempoLock(!ui.value.tempoLocked)
    fun toggleMetronome() = engine.setMetronome(!ui.value.metronome)
    fun toggleAutoFill() = engine.setAutoFill(!ui.value.autoFill)
    fun toggleRequireChord() = engine.setRequireChord(!ui.value.requireChord)
    fun transpose(d: Int) = engine.setTranspose(ui.value.transpose + d)
    fun chord(rootPc: Int, type: String) = engine.setChord(rootPc, type)
    fun pad(i: Int) = engine.triggerPad(i)
    fun padStop(i: Int) = engine.stopPad(i)

    fun tapTempo() {
        val now = SystemClock.elapsedRealtime()
        if (tapTimes.isNotEmpty() && now - tapTimes.last() > 2000) tapTimes.clear()
        tapTimes.addLast(now)
        while (tapTimes.size > 5) tapTimes.removeFirst()
        if (tapTimes.size >= 2) {
            val avg = (tapTimes.last() - tapTimes.first()).toDouble() / (tapTimes.size - 1)
            if (avg in 200.0..2000.0) engine.setTempo(60000.0 / avg)
        }
    }

    fun partIndex(p: PartId) = p.ordinal
}
