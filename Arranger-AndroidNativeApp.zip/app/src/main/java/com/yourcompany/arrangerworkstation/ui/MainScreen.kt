package com.yourcompany.arrangerworkstation.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yourcompany.arrangerworkstation.core.PartId
import com.yourcompany.arrangerworkstation.core.SectionId
import com.yourcompany.arrangerworkstation.core.TransportState
import com.yourcompany.arrangerworkstation.ui.theme.GlowButton
import com.yourcompany.arrangerworkstation.ui.theme.LevelMeter
import com.yourcompany.arrangerworkstation.ui.theme.Palette
import com.yourcompany.arrangerworkstation.ui.theme.Panel

@Composable
fun MainScreen(vm: ArrangerViewModel) {
    val ui by vm.ui.collectAsState()
    val levels by vm.levels.collectAsState()
    val snack = remember { SnackbarHostState() }

    val stylePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importStyle(uri) }
    var padTarget by remember { mutableIntStateOf(0) }
    val padPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importPad(padTarget, uri) }

    LaunchedEffect(vm.message) {
        vm.message?.let { snack.showSnackbar(it); vm.message = null }
    }

    Scaffold(
        containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        modifier = Modifier.background(Brush.verticalGradient(listOf(Palette.BgTop, Palette.Bg))),
    ) { inset ->
        LazyColumn(
            Modifier.fillMaxSize().padding(inset),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item { Header(vm, ui) { stylePicker.launch(arrayOf("*/*")) } }
            item { NowPlaying(vm, ui, levels) }
            item { TransportPanel(vm, ui) }
            item { SectionsPanel(vm, ui) }
            item { TempoPanel(vm, ui) }
            item { ChordPanel(vm, ui) }
            item { MixerPanel(vm, levels) }
            item { PadPanel(vm, ui) { i -> padTarget = i; padPicker.launch(arrayOf("*/*")) } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ------------------------------------------------------------------ header
@Composable
private fun Header(vm: ArrangerViewModel, ui: UiSnapshot, onOpen: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("ARRANGER", fontSize = 12.sp, letterSpacing = 3.sp, color = Palette.Violet, fontWeight = FontWeight.Bold)
            Text(ui.styleName, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Palette.Text, maxLines = 1)
            Text(vm.styleFile, fontSize = 12.sp, color = Palette.Dim, maxLines = 1)
        }
        GlowButton("OPEN .STY", Palette.Violet, Modifier.width(118.dp), active = true, height = 46, onClick = onOpen)
    }
}

// ------------------------------------------------------------------ now playing
@Composable
private fun NowPlaying(vm: ArrangerViewModel, ui: UiSnapshot, levels: List<Float>) {
    Panel("Now playing", trailing = { StatusChips(vm, ui) }) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SECTION", fontSize = 10.sp, letterSpacing = 2.sp, color = Palette.Dim)
                Text(ui.section.displayName, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Palette.Text)
                if (ui.queued != null) Text("next › ${ui.queued.displayName}", fontSize = 12.sp, color = Palette.Amber)
                Spacer(Modifier.height(8.dp))
                Text("CHORD", fontSize = 10.sp, letterSpacing = 2.sp, color = Palette.Dim)
                Text(ui.chord, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Palette.Cyan)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("BPM", fontSize = 10.sp, letterSpacing = 2.sp, color = Palette.Dim)
                Text(ui.tempo.toInt().toString(), fontSize = 52.sp, fontWeight = FontWeight.Black, color = Palette.Text)
                BeatDots(ui)
            }
        }
        Text("ACTIVE PARTS", fontSize = 10.sp, letterSpacing = 2.sp, color = Palette.Dim)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PartId.values().forEach { p ->
                val on = levels[p.ordinal] > 0.02f
                val c by animateColorAsState(if (on) Palette.partColors[p.ordinal] else Palette.Card2, label = "part")
                Box(Modifier.weight(1f).height(34.dp).background(c, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                    Text(shortName(p), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (on) Color(0xFF0A0F1C) else Palette.Dim)
                }
            }
        }
    }
}

private fun shortName(p: PartId) = when (p) {
    PartId.SubRhythm -> "SUB"; PartId.Rhythm -> "RHY"; PartId.Bass -> "BAS"; PartId.Chord1 -> "CH1"
    PartId.Chord2 -> "CH2"; PartId.Pad -> "PAD"; PartId.Phrase1 -> "PH1"; PartId.Phrase2 -> "PH2"
}

@Composable
private fun BeatDots(ui: UiSnapshot) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("BAR ${ui.bar}", fontSize = 11.sp, color = Palette.Dim, modifier = Modifier.padding(end = 4.dp))
        for (b in 1..4) {
            val on = ui.transport == TransportState.Playing && ui.beat == b
            val s by animateFloatAsState(if (on) 1.5f else 1f, spring(dampingRatio = 0.4f), label = "beat")
            Box(
                Modifier.size(10.dp).scale(s)
                    .background(if (on) (if (b == 1) Palette.Rose else Palette.Cyan) else Palette.Stroke, CircleShape),
            )
        }
    }
}

@Composable
private fun StatusChips(vm: ArrangerViewModel, ui: UiSnapshot) {
    val (txt, col) = when (ui.transport) {
        TransportState.Playing -> "● PLAYING" to Palette.Green
        TransportState.Stopped -> "■ STOPPED" to Palette.Dim
        TransportState.SyncArmedStart -> "◌ SYNC START" to Palette.Amber
        TransportState.SyncStopMode -> "◌ SYNC STOP" to Palette.Amber
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(txt, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = col)
        Text(
            if (vm.audioRunning) "AUDIO ${vm.audio.sampleRate / 1000.0} kHz" else "AUDIO OFF",
            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (vm.audioRunning) Palette.Cyan else Palette.Rose,
        )
    }
}

// ------------------------------------------------------------------ transport
@Composable
private fun TransportPanel(vm: ArrangerViewModel, ui: UiSnapshot) {
    val playing = ui.transport == TransportState.Playing || ui.transport == TransportState.SyncStopMode
    Panel("Transport") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowButton(if (playing) "■  STOP" else "▶  START", if (playing) Palette.Rose else Palette.Green,
                Modifier.weight(1.4f), active = playing, height = 64) { vm.playStop() }
            GlowButton("SYNC START", Palette.Amber, Modifier.weight(1f), active = ui.transport == TransportState.SyncArmedStart, height = 64) { vm.syncStart() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowButton("METRONOME", Palette.Cyan, Modifier.weight(1f), active = ui.metronome) { vm.toggleMetronome() }
            GlowButton("AUTO FILL", Palette.Amber, Modifier.weight(1f), active = ui.autoFill) { vm.toggleAutoFill() }
        }
        GlowButton("WAIT FOR CHORD (drums only until a chord)", Palette.Green, Modifier.fillMaxWidth(), active = ui.requireChord, height = 44) { vm.toggleRequireChord() }
    }
}

// ------------------------------------------------------------------ sections
@Composable
private fun SectionsPanel(vm: ArrangerViewModel, ui: UiSnapshot) {
    Panel("Style sections") {
        SectionRow(vm, ui, listOf(SectionId.Intro1, SectionId.Intro2, SectionId.Intro3), Palette.Cyan)
        SectionRow(vm, ui, listOf(SectionId.MainA, SectionId.MainB, SectionId.MainC, SectionId.MainD), Palette.Violet)
        SectionRow(vm, ui, listOf(SectionId.FillA, SectionId.FillB, SectionId.FillC, SectionId.FillD), Palette.Amber)
        SectionRow(vm, ui, listOf(SectionId.Break, SectionId.Ending1, SectionId.Ending2, SectionId.Ending3), Palette.Rose)
    }
}

@Composable
private fun SectionRow(vm: ArrangerViewModel, ui: UiSnapshot, ids: List<SectionId>, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ids.forEach { id ->
            GlowButton(
                id.displayName.uppercase(), color, Modifier.weight(1f),
                active = ui.section == id, pending = ui.queued == id, enabled = ui.available.contains(id),
            ) { vm.section(id) }
        }
    }
}

// ------------------------------------------------------------------ tempo
@Composable
private fun TempoPanel(vm: ArrangerViewModel, ui: UiSnapshot) {
    Panel("Tempo & key") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlowButton("−5", Palette.Blue, Modifier.weight(1f), enabled = !ui.tempoLocked) { vm.nudgeTempo(-5.0) }
            GlowButton("−1", Palette.Blue, Modifier.weight(1f), enabled = !ui.tempoLocked) { vm.nudgeTempo(-1.0) }
            GlowButton("+1", Palette.Blue, Modifier.weight(1f), enabled = !ui.tempoLocked) { vm.nudgeTempo(1.0) }
            GlowButton("+5", Palette.Blue, Modifier.weight(1f), enabled = !ui.tempoLocked) { vm.nudgeTempo(5.0) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlowButton("TAP TEMPO", Palette.Cyan, Modifier.weight(1f), enabled = !ui.tempoLocked) { vm.tapTempo() }
            GlowButton(if (ui.tempoLocked) "🔒 TEMPO LOCK" else "TEMPO LOCK", Palette.Amber, Modifier.weight(1f), active = ui.tempoLocked) { vm.toggleTempoLock() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            GlowButton("−", Palette.Violet, Modifier.width(56.dp)) { vm.transpose(-1) }
            Text("TRANSPOSE  ${if (ui.transpose > 0) "+" else ""}${ui.transpose}", Modifier.weight(1f), color = Palette.Text,
                fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            GlowButton("+", Palette.Violet, Modifier.width(56.dp)) { vm.transpose(1) }
        }
    }
}

// ------------------------------------------------------------------ chords
private val ROOTS = listOf("C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")
private val TYPES = listOf("Maj" to "Maj", "min" to "min", "7" to "7th", "Maj7" to "Maj7", "min7" to "min7", "sus4" to "sus4", "dim" to "dim", "aug" to "aug")

@Composable
private fun ChordPanel(vm: ArrangerViewModel, ui: UiSnapshot) {
    var root by remember { mutableIntStateOf(0) }
    var type by remember { mutableStateOf("Maj") }
    Panel("Chord input", trailing = {
        Text(if (ui.midiDevices.isEmpty()) "no MIDI keyboard" else "● ${ui.midiDevices.first()}", fontSize = 11.sp,
            color = if (ui.midiDevices.isEmpty()) Palette.Dim else Palette.Green)
    }) {
        Text("Play chords on a USB/Bluetooth MIDI keyboard (auto-detected), or tap a root and chord type below. Changes apply instantly while the style plays.",
            fontSize = 12.sp, color = Palette.Dim, lineHeight = 17.sp)
        for (rowIdx in 0..1) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in rowIdx * 6 until rowIdx * 6 + 6) {
                    GlowButton(ROOTS[i], Palette.Cyan, Modifier.weight(1f), active = root == i, height = 46) { root = i; vm.chord(i, type) }
                }
            }
        }
        for (rowIdx in 0..1) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (k in rowIdx * 4 until rowIdx * 4 + 4) {
                    val (label, name) = TYPES[k]
                    GlowButton(label, Palette.Violet, Modifier.weight(1f), active = type == name, height = 46) { type = name; vm.chord(root, name) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ mixer
@Composable
private fun MixerPanel(vm: ArrangerViewModel, levels: List<Float>) {
    val mx = vm.mixer
    Panel("Mixer") {
        MixSlider("Style volume", mx.styleVolume, 0f..1.2f, Palette.Violet) { mx.styleVolume = it }
        MixSlider("Bass volume", mx.bassVolume, 0f..1.6f, Palette.Green) { mx.bassVolume = it }
        MixSlider("Kick volume", mx.kickVolume, 0f..1.6f, Palette.Rose) { mx.kickVolume = it }
        MixSlider("Multi Pad volume", mx.padVolume, 0f..1.2f, Palette.Cyan) { mx.padVolume = it }
        MixSlider("Master", mx.masterVolume, 0f..1.2f, Palette.Amber) { mx.masterVolume = it }
        Spacer(Modifier.height(4.dp))
        PartId.values().forEach { p ->
            val pm = mx.part(p)
            var vol by remember { mutableFloatStateOf(pm.volume) }
            var mute by remember { mutableStateOf(pm.mute) }
            var solo by remember { mutableStateOf(pm.solo) }
            val c = Palette.partColors[p.ordinal]
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(p.displayName, Modifier.width(84.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
                    LevelMeter(levels[p.ordinal], c, Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    GlowButton("M", Palette.Rose, Modifier.width(40.dp), active = mute, height = 34) { mute = !mute; pm.mute = mute }
                    Spacer(Modifier.width(6.dp))
                    GlowButton("S", Palette.Amber, Modifier.width(40.dp), active = solo, height = 34) { solo = !solo; pm.solo = solo }
                }
                Slider(
                    value = vol, onValueChange = { vol = it; pm.volume = it }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c, activeTrackColor = c, inactiveTrackColor = Palette.Stroke),
                )
            }
        }
    }
}

@Composable
private fun MixSlider(label: String, initial: Float, range: ClosedFloatingPointRange<Float>, color: Color, onChange: (Float) -> Unit) {
    var v by remember { mutableFloatStateOf(initial) }
    Column {
        Row {
            Text(label, Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
            Text("${(v * 100).toInt()}%", fontSize = 12.sp, color = Palette.Dim)
        }
        Slider(
            value = v, onValueChange = { v = it; onChange(it) }, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color, inactiveTrackColor = Palette.Stroke),
        )
    }
}

// ------------------------------------------------------------------ multi pads
@Composable
private fun PadPanel(vm: ArrangerViewModel, ui: UiSnapshot, onLoad: (Int) -> Unit) {
    Panel("Multi pads") {
        for (rowIdx in 0..1) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in rowIdx * 2 until rowIdx * 2 + 2) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        GlowButton(ui.padNames[i].uppercase().take(14), Palette.Cyan, Modifier.fillMaxWidth(), active = ui.padActive[i], height = 84) { vm.pad(i) }
                        Text(vm.padFiles[i], fontSize = 10.sp, color = Palette.Dim, maxLines = 1)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            GlowButton("LOAD .MID", Palette.Blue, Modifier.weight(1f), height = 38) { onLoad(i) }
                            GlowButton("CHORD", Palette.Green, Modifier.weight(1f), active = vm.padChordTracked[i], height = 38) { vm.togglePadChordTracking(i) }
                        }
                    }
                }
            }
        }
    }
}
