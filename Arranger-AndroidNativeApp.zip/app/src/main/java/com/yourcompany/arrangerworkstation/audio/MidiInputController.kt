package com.yourcompany.arrangerworkstation.audio

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import com.yourcompany.arrangerworkstation.core.StyleEngine

/**
 * Receives note on/off from any connected USB or Bluetooth MIDI keyboard
 * (android.media.midi, API 23+) and feeds the arranger's chord
 * recognizer. The callback arrives on a MIDI thread, never the audio
 * thread, which is safe because StyleEngine.chordNoteOn/Off only enqueue
 * a command that the audio thread drains.
 */
class MidiInputController(context: Context, private val engine: StyleEngine) {
    private val manager = context.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val handler = Handler(Looper.getMainLooper())
    private val open = mutableMapOf<Int, Pair<MidiDevice, MidiOutputPort>>()
    @Volatile var deviceNames: List<String> = emptyList(); private set

    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            var i = offset
            val end = offset + count
            while (i < end) {
                val status = msg[i].toInt() and 0xFF
                if (status < 0x80) { i++; continue }
                val type = status and 0xF0
                val len = when (type) { 0xC0, 0xD0 -> 2; 0xF0 -> 1; else -> 3 }
                if (i + len > end) break
                if (type == 0x90 || type == 0x80) {
                    val note = msg[i + 1].toInt() and 0x7F
                    val vel = msg[i + 2].toInt() and 0x7F
                    if (type == 0x90 && vel > 0) engine.chordNoteOn(note) else engine.chordNoteOff(note)
                }
                i += len
            }
        }
    }

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) { openDevice(device) }
        override fun onDeviceRemoved(device: MidiDeviceInfo) { close(device.id) }
    }

    fun start() {
        val m = manager ?: return
        for (info in m.devices) openDevice(info)
        m.registerDeviceCallback(callback, handler)
    }

    fun stop() {
        manager?.unregisterDeviceCallback(callback)
        for (id in open.keys.toList()) close(id)
    }

    private fun openDevice(info: MidiDeviceInfo) {
        val m = manager ?: return
        if (info.outputPortCount <= 0 || open.containsKey(info.id)) return
        m.openDevice(info, { device ->
            if (device != null) {
                val port = device.openOutputPort(0)
                if (port != null) {
                    port.connect(receiver)
                    open[info.id] = device to port
                    refreshNames()
                } else device.close()
            }
        }, handler)
    }

    private fun close(id: Int) {
        open.remove(id)?.let { (dev, port) ->
            try { port.disconnect(receiver); port.close(); dev.close() } catch (e: Exception) {}
        }
        refreshNames()
    }

    private fun refreshNames() {
        deviceNames = open.values.map { (dev, _) ->
            dev.info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device"
        }
    }
}
