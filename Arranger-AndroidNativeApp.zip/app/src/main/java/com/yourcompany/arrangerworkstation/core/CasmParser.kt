package com.yourcompany.arrangerworkstation.core

/**
 * Parses the CASM chunk (CSEG -> Sdec + Ctab/Ctb2 + optional Cntt). Every offset and bit
 * position below was checked against the public community document "Style Files -
 * Introduction and Details" v2.1 (tables 7-17 and chapter 5.2).
 */
object CasmParser {

    private val SOURCE_CHORD_TYPES = arrayOf(
        "Maj", "Maj6", "Maj7", "Maj7#11", "Maj(9)", "Maj7(9)", "Maj6(9)", "aug",
        "min", "min6", "min7", "min7b5", "min(9)", "min7(9)", "min7(11)", "minMaj7",
        "minMaj7(9)", "dim", "dim7", "7th", "7sus4", "7b5", "7(9)", "7#11",
        "7(13)", "7(b9)", "7(b13)", "7(#9)", "Maj7aug", "7aug", "1+8", "1+5",
        "sus4", "1+2+5", "cancel",
    )

    // Chord Mute bit tables: [byte index 13..17][bit] -> chord name ("" = not a chord bit).
    private val CHORD_BITS: Array<Array<String>> = arrayOf(
        arrayOf("sus4", "1+2+5", "", "", "", "", "", ""),                                         // byte 13 (bit2 = autostart)
        arrayOf("7(13)", "7(b9)", "7(b13)", "7(#9)", "Maj7aug", "7aug", "1+8", "1+5"),            // byte 14
        arrayOf("minMaj7(9)", "dim", "dim7", "7th", "7sus4", "7b5", "7(9)", "7#11"),              // byte 15
        arrayOf("min", "min6", "min7", "min7b5", "min(9)", "min7(9)", "min7(11)", "minMaj7"),     // byte 16
        arrayOf("Maj", "Maj6", "Maj7", "Maj7#11", "Maj(9)", "Maj7(9)", "Maj6(9)", "aug"),         // byte 17
    )

    private fun ctabNtt(v: Int): Ntt = when (v and 0x7F) {
        0 -> Ntt.Bypass; 1 -> Ntt.Melody; 2 -> Ntt.Chord; 3 -> Ntt.Bass
        4 -> Ntt.MelodicMinor; 5 -> Ntt.HarmonicMinor
        else -> Ntt.Chord
    }

    // Ctb2 / Cntt numbering (differs from Ctab): there is no "Bass" value; bit 7 = "Bass on".
    private fun cnttNtt(v: Int): Ntt = when (v and 0x7F) {
        0 -> Ntt.Bypass; 1 -> Ntt.Melody; 2 -> Ntt.Chord
        3, 4, 7, 8, 9, 10 -> Ntt.MelodicMinor      // natural minor / dorian variants collapsed (documented)
        5, 6 -> Ntt.HarmonicMinor
        else -> Ntt.Chord
    }

    private fun rtrFrom(v: Int): Rtr = when (v) {
        0 -> Rtr.Stop; 1 -> Rtr.PitchShift; 2 -> Rtr.PitchShiftToRoot
        3 -> Rtr.Retrigger; 4 -> Rtr.RetriggerToRoot; 5 -> Rtr.NoteGenerator
        else -> Rtr.PitchShift
    }

    fun parse(data: ByteArray): Map<SectionId, List<ChannelMapping>> {
        val result = mutableMapOf<SectionId, MutableList<ChannelMapping>>()
        var pos = 0
        while (pos + 8 <= data.size) {
            if (idAt(data, pos) != "CSEG") break
            val len = u32be(data, pos + 4)
            val segStart = pos + 8
            val segEnd = segStart + len
            if (len < 0 || segEnd > data.size) break
            parseCseg(data, segStart, segEnd, result)
            pos = segEnd
        }
        return result
    }

    private fun parseCseg(data: ByteArray, start: Int, end: Int, out: MutableMap<SectionId, MutableList<ChannelMapping>>) {
        var pos = start
        if (idAt(data, pos) != "Sdec") return
        val sdecLen = u32be(data, pos + 4)
        val sdecStart = pos + 8
        if (sdecLen < 0 || sdecStart + sdecLen > end) return
        val names = String(data, sdecStart, sdecLen, Charsets.ISO_8859_1).split(",")
        val sectionIds = names.mapNotNull { SectionId.fromMarkerText(it.trim { c -> c == '\u0000' || c.isWhitespace() }) }
        pos = sdecStart + sdecLen

        val mappings = mutableListOf<ChannelMapping>()
        while (pos + 8 <= end) {
            val id = idAt(data, pos)
            val len = u32be(data, pos + 4)
            val bodyStart = pos + 8
            val bodyEnd = bodyStart + len
            if (len < 0 || bodyEnd > end) break
            when (id) {
                "Ctab" -> if (len >= 26) mappings.add(parseCtab(data, bodyStart))
                "Ctb2" -> if (len >= 34) mappings.add(parseCtb2(data, bodyStart))
                "Cntt" -> applyCntt(data, bodyStart, len, mappings)
                else -> { /* unknown/future structure - skip */ }
            }
            pos = bodyEnd
        }
        for (sid in sectionIds) out.getOrPut(sid) { mutableListOf() }.addAll(mappings)
    }

    private class Common(
        val sourceChannel: Int, val destPart: PartId, val root: Int, val tones: Set<Int>,
        val noteMask: Int, val chordPlays: Set<String>, val autoStart: Boolean,
    )

    /** Bytes 0..19 are identical for Ctab and Ctb2. */
    private fun common(d: ByteArray, o: Int): Common {
        val src = d[o].toInt() and 0x0F
        val destRaw = d[o + 9].toInt() and 0xFF                       // 08H..0FH = channels 9..16
        val part = PartId.forDestChannel(destRaw + 1) ?: PartId.Chord1
        // Note Mute: byte 11 bits0-3 = G# A Bb B (notes 8..11); byte 12 bits0-7 = C..G (notes 0..7). 1 = plays.
        val b11 = d[o + 11].toInt() and 0x0F
        val b12 = d[o + 12].toInt() and 0xFF
        val noteMask = b12 or (b11 shl 8)
        val plays = HashSet<String>()
        for (bi in 0 until 5) {
            val b = d[o + 13 + bi].toInt() and 0xFF
            for (bit in 0 until 8) {
                val name = CHORD_BITS[bi][bit]
                if (name.isNotEmpty() && ((b shr bit) and 1) == 1) plays.add(name)
            }
        }
        val autoStart = ((d[o + 13].toInt() shr 2) and 1) == 1
        val root = (d[o + 18].toInt() and 0xFF).coerceIn(0, 11)
        val typeIdx = (d[o + 19].toInt() and 0xFF).coerceIn(0, SOURCE_CHORD_TYPES.size - 1)
        return Common(src, part, root, ChordCatalog.lookup(SOURCE_CHORD_TYPES[typeIdx]), noteMask, plays, autoStart)
    }

    private fun parseCtab(d: ByteArray, o: Int): ChannelMapping {
        val c = common(d, o)
        val ntr = if ((d[o + 20].toInt() and 0xFF) == 0) Ntr.RootTrans else Ntr.RootFixed
        return ChannelMapping(
            c.sourceChannel, c.destPart, ntr, ctabNtt(d[o + 21].toInt() and 0xFF), c.root, c.tones,
            (d[o + 22].toInt() and 0xFF).coerceIn(0, 11), d[o + 23].toInt() and 0xFF, d[o + 24].toInt() and 0xFF,
            rtrFrom(d[o + 25].toInt() and 0xFF), c.noteMask, c.chordPlays, c.autoStart,
        )
    }

    /**
     * Ctb2 splits notes into low / middle / high ranges (bytes 22-27 / 28-33 / 34-39), each with
     * NTR, NTT, High Key, Low, High, RTR. The MIDDLE range is used for the whole channel - a
     * documented simplification.
     */
    private fun parseCtb2(d: ByteArray, o: Int): ChannelMapping {
        val c = common(d, o)
        val s = o + 28
        val ntr = when (d[s].toInt() and 0xFF) { 0 -> Ntr.RootTrans; 2 -> Ntr.Guitar; else -> Ntr.RootFixed }
        return ChannelMapping(
            c.sourceChannel, c.destPart, ntr, cnttNtt(d[s + 1].toInt() and 0xFF), c.root, c.tones,
            (d[s + 2].toInt() and 0xFF).coerceIn(0, 11), d[s + 3].toInt() and 0xFF, d[s + 4].toInt() and 0xFF,
            rtrFrom(d[s + 5].toInt() and 0xFF), c.noteMask, c.chordPlays, c.autoStart,
        )
    }

    /** Cntt (2 data bytes: source channel, NTT) overrides the NTT of the matching Ctab. */
    private fun applyCntt(d: ByteArray, o: Int, len: Int, mappings: MutableList<ChannelMapping>) {
        if (len < 2 || o + 2 > d.size) return
        val ch = d[o].toInt() and 0x0F
        val idx = mappings.indexOfLast { it.sourceChannel0to15 == ch }
        if (idx >= 0) mappings[idx] = mappings[idx].copy(ntt = cnttNtt(d[o + 1].toInt() and 0xFF))
    }

    private fun idAt(d: ByteArray, o: Int): String =
        if (o >= 0 && o + 4 <= d.size) String(d, o, 4, Charsets.ISO_8859_1) else ""

    private fun u32be(d: ByteArray, o: Int): Int =
        ((d[o].toInt() and 0xFF) shl 24) or ((d[o + 1].toInt() and 0xFF) shl 16) or
            ((d[o + 2].toInt() and 0xFF) shl 8) or (d[o + 3].toInt() and 0xFF)
}
