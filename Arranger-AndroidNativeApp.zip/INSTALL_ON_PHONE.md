# Get the app onto your phone (no zip, no Android Studio)

An APK has to be compiled, and that needs the Android SDK. This project builds it **in the cloud for free**:

1. Create a free account at github.com and make a **New repository** (any name, Public or Private).
2. On the repository page choose **Add file ▸ Upload files**, drag in the *contents* of this `AndroidNativeApp`
   folder (including the hidden `.github` folder), and press **Commit changes**.
3. Open the **Actions** tab ▸ **Build APK** ▸ wait ~5-8 minutes for the green tick.
   (If it shows red, open the failed step and send me the log - that is the real compile result.)
4. Open the repository's **Releases** (right-hand side). On your phone, tap **Arranger.apk**.
5. Allow "Install unknown apps" for your browser when Android asks, then tap **Install**.

The first build is also the first time this code is compiled by anything, so expect that it may need a fix or two.
